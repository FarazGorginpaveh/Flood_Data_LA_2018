# Louisiana 2018 flood / hazard exposure dataset - data README

Dated flood and hazard events for every Louisiana **ZCTA** and **county (parish)** in 2018,
built to study how extreme flooding relates to acute hospitalization. Each event has a unique
ID, a type, start and end dates, severity measures, and the list of other ZCTAs and counties it
affected. Full technical documentation: `README.md`. Variable definitions:
`DATA_DICTIONARY_LA_2018.csv` (also `.md`; in the repository `docs\` folder).

---

## 1. The key files

All are created by the pipeline on the project computer, under
`D:\Tufts\Wishlist\Sepideh_2\data\deliverable\`.

| # | File | One row per | Key | Use it for |
|---|---|---|---|---|
| 1 | **`MASTER_event_zcta_LA_2018.csv`** | event × ZCTA | `event_id` + `zcta` | **The main table.** Everything requested, columns in the order of the requirements |
| 2 | `csv\County_events_LA_2018.csv` | event × county | `storm_id` + `county_fips` | County-level analysis |
| 3 | `csv\Storms_LA_2018.csv` | event | `storm_id` | Overview of all events: dates, type, all ZCTAs and counties |
| 4 | `csv\ZCTA_daily_LA_2018.csv` | ZCTA × day | `zcta` + `date` | Daily time series (explicit zeros) |
| 5 | `csv\County_daily_LA_2018.csv` | county × day | `county_fips` + `date` | Daily county time series |
| 6 | `csv\ZCTA_universe_LA_2018.csv` | ZCTA | `zcta` | Which measures exist for each ZCTA (zero vs missing) |
| 7 | `csv\County_universe_LA_2018.csv` | county | `county_fips` | Confidence and data source per county |
| - | `LA_2018_flood_hazard_dataset.xlsx` | - | - | All of the above in one workbook, plus README and Dictionary sheets |

`storm_id` in files 2-5 is the same identifier as `event_id` in the MASTER table.

---

## 2. What an "event" is

- **Hazards** (per ZCTA and day):
  **stream flooding** (the ZCTA's own NWM stream reaches above their 2-year flow; USGS gauges where available),
  **stream flooding imputed** from the county (ZCTAs with too few streams, mostly small urban ZCTAs),
  **heavy rain** (AORC rainfall with a NOAA Atlas 14 return period ≥ 2 years),
  **coastal flooding** (nearest NOAA tide gauge at or above the minor flood level),
  **tropical cyclone** within 100 km (NOAA HURDAT2).
- **One event = one weather system.** ZCTAs flooded in neighbouring areas within a day of each
  other, or linked to the same NWS storm episode, share one ID; separate areas of the same system
  (≤ 150 km apart, same days) are joined; long wet periods are split at their quietest day.
  IDs: `LA2018_S###` (events with stream flooding), `LA2018_H###` (hazard-only events).
- **In the MASTER table, each row describes one ZCTA in one event**: its own dates and
  measures, plus the other ZCTAs and counties of the same event.

---

## 3. Conventions

| Topic | Rule |
|---|---|
| Spatial units | ZCTA, **2020 U.S. Census boundaries**; county = Louisiana parish (county FIPS). Each ZCTA belongs to the county holding most of its land |
| Time | Local calendar days, America/Chicago |
| Rows absent | A ZCTA absent for an event had **no hazard that can be measured there** (see the universe file): stream flooding is missing for 18 ZCTAs (Cameron, Plaquemines, St. Bernard); rainfall and cyclones are measured everywhere; coastal flooding only where `has_tide_gauge` = 1 |
| Daily tables | 0 = measured and absent; blank = not measured |
| Blank cells | Missing / not applicable; the reason is in the dictionary (`missingness`). No numeric missing codes |
| Magnitude flag | `flood_magnitude_source` = observed (USGS) / modeled (NWM) / imputed (parish) / none |
| Codes | Read `zcta`, `county_fips` as **text** to keep all 5 characters |

Reading the main table:

```python
import pandas as pd
m = pd.read_csv("MASTER_event_zcta_LA_2018.csv",
                dtype={"zcta": str, "county_fips": str},
                parse_dates=["event_start_date", "event_end_date", "zcta_start_date", "zcta_end_date"])
```

```r
m <- readr::read_csv("MASTER_event_zcta_LA_2018.csv",
                     col_types = readr::cols(zcta = "c", county_fips = "c"))
```

---

## 4. Requirement → MASTER column

| Requirement | Column(s) |
|---|---|
| Unique event ID | `event_id` |
| Event type | `event_type`, `event_type_basis`, `hazards`, `hazard_*` flags |
| Start and end dates and hours | `event_start_date`, `event_end_date` (whole event); `zcta_start_date`, `zcta_end_date`, `zcta_peak_date` |
| Magnitude | `flood_magnitude` (peak / 2-year flow), `flood_return_period_yr`, `flood_return_period_class` |
| Observed / modeled / imputed flag | `flood_magnitude_source` |
| Flood depth | `flood_depth_*` - **not yet available** (blank); observed hint: `observed_depth_insured_buildings_*` (NFIP claims) |
| Duration | `flood_duration_days` |
| Onset to peak | `onset_to_peak_hours` |
| Intensity / severity | `severity_index`, `severity_composite` (optional 0-1 composite) |
| Extent | `extent_share_stream_reaches` (proxy), `county_share_zctas_affected`, `county_share_land_affected` |
| Precipitation | `precip_event_total_mm`, `precip_max_24h_mm`, `precip_max_24h_return_period_yr`, `precip_max_1h_mm`, `precip_max_1h_return_period_yr` |
| Coastal / cyclone | `coastal_flood_class`, `coastal_water_level_m_above_mhhw`, `tropical_cyclone_*` |
| Other ZCTAs / counties impacted | `other_zctas_flooded_same_days`, `other_zctas_flooded_in_event`, `other_counties_flooded_*`, `other_zctas_in_event` (any hazard), `counties_in_event`, with counts |
| Reliability | `confidence`, `n_stream_reaches` |

---

## 5. The pipeline: steps and their role

| Step | Script | Role |
|---|---|---|
| 01 | `01_download_usgs_streamflow.py` | Observed USGS river flow and water level (15-min), annual peaks, flood thresholds |
| 02 | `02_check_usgs_data.py` | What USGS alone can cover (73 flow gauges; 23 counties without one) |
| 03 | `03_download_nwm_retrospective.py` | Modeled flow for all 43,240 Louisiana stream reaches; 43-year annual maxima → each reach's 2-year flow |
| 05 | `05_extract_flood_events.py` | Flood events per reach and gauge: magnitude, rise time, severity |
| 06 | `06_evaluate_nwm.py` | Model vs gauges → confidence level per county |
| 07 | `07_parish_dataset.py` | County (parish) daily, event and annual flood tables |
| 07b | `07b_diagnose_long_blocks.py` | Finds artifacts (stuck lake reaches, tidal marsh, pumped bayou) |
| 07c | `07c_make_reviewed_exclusions.py` | Saves the reviewed exclusion list (then step 07 is re-run) |
| 08 | `08_validate_storm_events.py` | Validation with NWS flood reports (66% detected) |
| 09 | `09_zcta_dataset.py` | ZCTA daily, event and annual flood tables |
| 10 | `10_enrich_zcta_events.py` | Storm IDs, event types, return periods, observed/modeled flag, storm ZCTA/county lists |
| 11 | `11_validate_nfip_claims.py` | Validation with FEMA flood insurance claims (64% county, 77% ZCTA) |
| 12 | `12_rainfall_aorc.py` | Hourly rainfall per ZCTA and its return period (Atlas 14) |
| 13 | `13_coastal_hurricane.py` | Tropical-cyclone exposure and tide-gauge coastal flooding |
| 14 | `14_final_event_zcta_table.py` | All-hazard events per ZCTA, parish imputation, daily table, universe |
| 15 | `15_comprehensive_file.py` | County events, storm table, **MASTER table**, workbook, dictionary |

(Step 04 was planned - NWS flood stages - and not needed.)

---

## 6. Louisiana 2018 at a glance

- **83 events** (62 with stream flooding, 21 hazard-only); **1,661 event × ZCTA rows**;
  463 of 540 ZCTAs with at least one event.
- Largest events: the late-February flood (main day 26 Feb), the late-December storm
  (27-31 Dec; largest insurance losses) and the end-of-March storm; Tropical Storm Gordon
  (4 Sep, passed 30 km from the nearest Louisiana ZCTA; 24 ZCTAs within 100 km).
- Validation: NWM vs USGS hourly correlation 0.83; 66% of NWS-reported floods and
  64% (county) / 77% (ZCTA) of NFIP claim events detected.

## 7. Limitations

- Stream flooding is riverine; **urban drainage flooding is under-represented** in every
  streamflow source - use the precipitation columns in urban ZCTAs.
- **No flood depth or flooded area yet** (extent columns are proxies).
- Coastal flooding only near tide gauges; most coastal rows are *minor* (use moderate/major for
  extreme coastal events).
- Imputed rows give small ZCTAs their county's flood days (`confidence` = "low (imputed)");
  test results without them.
- Return periods above ~43 years are extrapolations (capped at 100).

## 8. Sources

USGS Water Data APIs · NOAA National Water Model v3.0 retrospective · NOAA AORC v1.1 ·
NOAA Atlas 14 · NOAA CO-OPS tide gauges · NOAA HURDAT2 · NOAA NCEI Storm Events ·
FEMA OpenFEMA NFIP claims · U.S. Census Bureau 2020 ZCTAs and relationship files.
Method inspired by Khajehei et al. (2020), *Scientific Reports* 10:448.
