"""
STEP 11 - Validate the flood dataset with FEMA flood insurance (NFIP) claims, 2018
=================================================================================
Every NFIP claim is a building that was actually damaged by flooding, with a
date of loss, a county (parish) code and a ZIP code. That makes claims an
independent, ground-level check of the dataset - including urban floods that
the NWS may never have reported.

What it checks (a +/- TOL_DAYS window allows for dates entered a day off)
  PARISH level (data/final)
    claim-event detection : share of parish "claim events" (>= MIN_CLAIMS_PARISH
                            claims on a day, days <= 1 apart joined) that fall on
                            a dataset flood day
    claims captured       : share of all claims that fall on a dataset flood day
    confirmation          : share of dataset parish events with >= 1 claim
    rank correlation      : do parishes with more flood days also have more claims?
    (local floods, and local + big-river floods)
  ZCTA level (data/zcta, claims placed by ZIP code)
    same measures, in the same ZCTA and in the ZCTA or a neighbouring ZCTA
  STORM level (data/zcta/storms_2018.csv)
    claims, paid amounts and reported water depth inside each storm's
    ZCTAs and dates -> storms_2018_with_claims.csv
  Everything is split by confidence level.

Data : OpenFEMA "FIMA NFIP Redacted Claims" (no key needed)
       v3 endpoint  https://www.fema.gov/api/open/v3/NfipClaims  (used first)
       v2 endpoint  https://www.fema.gov/api/open/v2/FimaNfipClaims (fallback;
                    FEMA retires it on 15 Oct 2026, data frozen since 1 Jun 2026)
       or a file you downloaded yourself: --claims-file path\\to\\claims.csv
Notes: FEMA redacts claims (no addresses; lat/lon rounded to 0.1 degree), so
       ZIP code and county are the right levels. ZIP codes approximate ZCTAs;
       claims with ZIPs that are not a Louisiana ZCTA are counted separately.
       Claims only exist where people carry flood insurance, so counts reflect
       insurance uptake as well as flooding - compare patterns, not raw totals.

Inputs : data/final/parish_daily_2018.csv, parish_events_2018.csv (step 7)
         data/zcta/zcta_daily_2018.csv, zcta_events_2018.csv,
         zcta_boundaries_LA.gpkg, storms_2018.csv (steps 9-10; optional)
Outputs: data/nfip/  (claims file, validation tables, summary, fig15)
Usage  : python 11_validate_nfip_claims.py
"""

import os
import argparse
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import requests

# ----------------------------------------------------------------------------
# CONFIGURATION
# ----------------------------------------------------------------------------
PROJECT_DIR = Path(os.environ.get("FLOOD_PROJECT_DIR", r"D:\Tufts\Wishlist\Sepideh_3"))
YEAR = int(os.environ.get("FLOOD_YEAR", "2018"))   # set by run_all_years.py
STATE = "LA"
TOL_DAYS = 1
MIN_CLAIMS_PARISH = 3     # a parish "claim event" needs >= 3 claims on a day
MIN_CLAIMS_ZCTA = 2       # a ZCTA "claim event" needs >= 2 claims on a day
PAGE = 1000
ENDPOINTS = [("v3", "https://www.fema.gov/api/open/v3/NfipClaims"),
             ("v2", "https://www.fema.gov/api/open/v2/FimaNfipClaims")]
FIELDS = ["id", "dateOfLoss", "yearOfLoss", "state", "countyCode", "reportedZipCode",
          "floodEvent", "causeOfDamage", "amountPaidOnBuildingClaim",
          "amountPaidOnContentsClaim", "buildingDamageAmount", "contentsDamageAmount",
          "waterDepth", "latitude", "longitude", "ratedFloodZone", "occupancyType"]
CONF_ORDER = ["high", "medium", "low", "unverified", "no data"]


def set_paths(project_dir):
    global D, OUT, FIG
    D = project_dir / "data"
    OUT = D / "nfip"
    FIG = OUT / "figures"
    FIG.mkdir(parents=True, exist_ok=True)


def to_day(x):
    return pd.to_datetime(pd.Series(x).astype(str).str[:10], errors="coerce").to_numpy()


# ----------------------------------------------------------------------------
# 1. DOWNLOAD CLAIMS
# ----------------------------------------------------------------------------
def fetch_claims(user_file=None):
    cache = OUT / f"nfip_claims_{STATE}_{YEAR}.csv"
    if user_file:
        return pd.read_csv(user_file, dtype=str, low_memory=False)
    if cache.exists():
        return pd.read_csv(cache, dtype=str, low_memory=False)

    filt = f"state eq '{STATE}' and yearOfLoss eq {YEAR}"
    for ver, url in ENDPOINTS:
        for use_select in (True, False):
            rows, skip = [], 0
            try:
                while True:
                    params = {"$filter": filt, "$top": PAGE, "$skip": skip}
                    if use_select:
                        params["$select"] = ",".join(FIELDS)
                    r = requests.get(url, params=params, timeout=180)
                    if r.status_code == 429:
                        time.sleep(30)
                        continue
                    r.raise_for_status()
                    js = r.json()
                    recs = next((v for k, v in js.items()
                                 if k != "metadata" and isinstance(v, list)), [])
                    rows.extend(recs)
                    print(f"  {ver}: {len(rows):,} claims downloaded", end="\r")
                    if len(recs) < PAGE:
                        break
                    skip += PAGE
                df = pd.DataFrame(rows)
                if len(df):
                    print(f"\n  downloaded {len(df):,} claims from OpenFEMA {ver}")
                    df.to_csv(cache, index=False)
                    return pd.read_csv(cache, dtype=str, low_memory=False)
                print(f"\n  ! {ver} returned no claims")
            except Exception as exc:
                print(f"\n  ! OpenFEMA {ver} ({'with' if use_select else 'without'} $select) "
                      f"failed: {str(exc)[:120]}")
    raise RuntimeError("Could not download claims. Download them from the OpenFEMA 'FIMA NFIP "
                       "Redacted Claims' page and pass --claims-file")


def clean_claims(c, zctas):
    cols = {k.lower(): k for k in c.columns}
    get = lambda name: c[cols[name.lower()]] if name.lower() in cols else pd.Series(np.nan, index=c.index)
    out = pd.DataFrame({
        "claim_id": get("id"),
        "date": to_day(get("dateOfLoss")),
        "parish_fips": get("countyCode").astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(5),
        "zip": get("reportedZipCode").astype(str).str.replace(r"\.0$", "", regex=True).str[:5].str.zfill(5),
        "flood_event_name": get("floodEvent"),
        "paid": pd.to_numeric(get("amountPaidOnBuildingClaim"), errors="coerce").fillna(0)
                + pd.to_numeric(get("amountPaidOnContentsClaim"), errors="coerce").fillna(0),
        "damage": pd.to_numeric(get("buildingDamageAmount"), errors="coerce").fillna(0)
                  + pd.to_numeric(get("contentsDamageAmount"), errors="coerce").fillna(0),
        "water_depth_in": pd.to_numeric(get("waterDepth"), errors="coerce"),
    })
    out = out[(pd.to_datetime(out.date).dt.year == YEAR) & out.parish_fips.str.startswith("22")]
    out["zcta"] = np.where(out.zip.isin(zctas), out.zip, None)
    return out.reset_index(drop=True)


# ----------------------------------------------------------------------------
# 2. GENERIC VALIDATION FOR ONE SPATIAL LEVEL
# ----------------------------------------------------------------------------
def claim_events(claims, key, min_claims):
    """Days with >= min_claims claims in an area, joined when <= 1 day apart."""
    daily = claims.groupby([key, "date"]).agg(n=("claim_id", "size"), paid=("paid", "sum")) \
        .reset_index()
    daily = daily[daily.n >= min_claims].sort_values([key, "date"])
    rows = []
    for k, g in daily.groupby(key):
        start = prev = None
        n = paid = 0
        for d, nn, pp in zip(g.date, g.n, g.paid):
            if start is not None and (d - prev).days <= 2:
                prev, n, paid = d, n + nn, paid + pp
                continue
            if start is not None:
                rows.append((k, start, prev, n, paid))
            start = prev = d
            n, paid = nn, pp
        if start is not None:
            rows.append((k, start, prev, n, paid))
    return pd.DataFrame(rows, columns=[key, "start", "end", "n_claims", "paid"])


def flood_set(daily, key, col):
    m = daily[col].fillna(False).astype(bool)
    return set(zip(daily.loc[m, key], pd.to_datetime(daily.loc[m, "date"])))


def hit(area, start, end, fset, neigh=None):
    tol = pd.Timedelta(days=TOL_DAYS)
    areas = {area} | (neigh.get(area, set()) if neigh else set())
    return any((a, d) in fset for a in areas for d in pd.date_range(start - tol, end + tol))


def validate_level(claims, daily, events, key, conf_col, min_claims, flood_col="flood_day",
                   neigh=None, label=""):
    have = daily[~daily[conf_col].isin(["no data"]) & ~daily.get("source", pd.Series("", index=daily.index)).eq("none")]
    areas = set(have[key])
    cl = claims[claims[key].isin(areas)]
    fset = flood_set(have, key, flood_col)

    ce = claim_events(cl, key, min_claims)
    ce["detected"] = [hit(a, s, e, fset) for a, s, e in zip(ce[key], ce.start, ce.end)]
    if neigh:
        ce["detected_with_neighbours"] = [hit(a, s, e, fset, neigh)
                                          for a, s, e in zip(ce[key], ce.start, ce.end)]
    cl = cl.assign(on_flood_day=[hit(a, d, d, fset) for a, d in zip(cl[key], cl.date)])

    ev = events[events[key].isin(areas)].copy()
    ev["s"], ev["e"] = to_day(ev.start_date), to_day(ev.end_date)
    cday = set(zip(cl[key], cl.date))
    tol = pd.Timedelta(days=TOL_DAYS)
    ev["n_claims"] = [sum(((a, d) in cday) for d in pd.date_range(s - tol, e + tol))
                      for a, s, e in zip(ev[key], ev.s, ev.e)]
    ev["confirmed"] = ev.n_claims > 0

    ann = have.groupby(key).agg(flood_days=(flood_col, lambda s: s.fillna(False).astype(bool).sum()),
                                confidence=(conf_col, "first"))
    ann["claims"] = cl.groupby(key).size().reindex(ann.index).fillna(0)
    # Spearman rank correlation (computed from ranks, so scipy is not needed)
    rho = ann.flood_days.rank().corr(ann.claims.rank()) if len(ann) > 3 else np.nan

    conf = ce.assign(g=ce[key].map(ann.confidence)).groupby("g").agg(
        claim_events=("detected", "size"), detected=("detected", "sum"))
    conf["detection_rate"] = conf.detected / conf.claim_events
    conf = conf.reindex([c for c in CONF_ORDER if c in conf.index])

    s = {"level": label,
         "claims_in_areas_with_data": len(cl),
         "claims_on_flood_days": int(cl.on_flood_day.sum()),
         "share_claims_captured": cl.on_flood_day.mean() if len(cl) else np.nan,
         "claim_events": len(ce),
         "claim_events_detected": int(ce.detected.sum()),
         "detection_rate": ce.detected.mean() if len(ce) else np.nan,
         "dataset_events": len(ev),
         "dataset_events_with_claims": int(ev.confirmed.sum()),
         "confirmation_rate": ev.confirmed.mean() if len(ev) else np.nan,
         "spearman_flood_days_vs_claims": rho}
    if neigh:
        s["detection_rate_with_neighbours"] = ce.detected_with_neighbours.mean() if len(ce) else np.nan
    return s, ce, ev, cl, conf, ann


# ----------------------------------------------------------------------------
# 3. FIGURE
# ----------------------------------------------------------------------------
def figure(claims, pdaily, p_ann, p_conf, z_conf, p_ce, shapes_path):
    fig, axes = plt.subplots(2, 2, figsize=(14, 11))

    ax = axes[0, 0]
    days = pd.date_range(f"{YEAR}-01-01", f"{YEAR}-12-31")
    c = claims.groupby(pd.to_datetime(claims.date)).size().reindex(days, fill_value=0)
    fl = pdaily[pdaily.flood_day.fillna(False).astype(bool)].groupby("date").size().reindex(days, fill_value=0)
    ax.bar(days, fl.values, width=1, color="#9ecae1", label="parishes with a dataset flood day")
    ax2 = ax.twinx()
    ax2.plot(c.index, c.values, color="#d62728", lw=0.9, label="NFIP claims per day")
    ax.set(ylabel="parishes flooding", title=f"A. Dataset flood days vs NFIP claims, {YEAR}")
    ax2.set_ylabel("claims per day", color="#d62728")
    h1, l1 = ax.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, fontsize=8, loc="upper right")

    ax = axes[0, 1]
    a = p_ann[p_ann.claims > 0]
    cols = a.confidence.map({"high": "#2ca02c", "medium": "#ffbf00", "low": "#d62728"}).fillna("#999999")
    ax.scatter(a.flood_days + 0.5, a.claims, c=cols, s=35, edgecolor="k", lw=0.3)
    ax.set(xscale="log", yscale="log", xlabel="dataset flood days (+0.5)",
           ylabel=f"NFIP claims in {YEAR}",
           title="B. Parishes: flood days vs claims (colour = confidence)")

    ax = axes[1, 0]
    groups = [g for g in ["high", "medium", "low"] if g in p_conf.index or (z_conf is not None and g in z_conf.index)]
    x = np.arange(len(groups))
    pv = [100 * p_conf.detection_rate.get(g, np.nan) for g in groups]
    ax.bar(x - 0.2, pv, 0.4, color="#1f77b4", label="parish claim events detected")
    if z_conf is not None:
        zv = [100 * z_conf.detection_rate.get(g, np.nan) for g in groups]
        ax.bar(x + 0.2, zv, 0.4, color="#ff7f0e", label="ZCTA claim events detected")
    ax.set(xticks=x, xticklabels=groups, ylim=(0, 105), ylabel="%",
           title="C. Claim events on a dataset flood day, by confidence")
    ax.legend(fontsize=8)

    ax = axes[1, 1]
    try:
        import geopandas as gpd
        par = gpd.read_file(shapes_path)
        par["fips"] = par["id"].astype(str)
        rate = p_ce.groupby("parish_fips").detected.mean()
        par["rate"] = par.fips.map(rate)
        par[par.rate.isna()].plot(ax=ax, color="#eeeeee", edgecolor="#999999", lw=0.3)
        if par.rate.notna().any():
            par[par.rate.notna()].plot(ax=ax, column="rate", cmap="RdYlGn", vmin=0, vmax=1,
                                       edgecolor="#666666", lw=0.3, legend=True,
                                       legend_kwds={"shrink": 0.6, "label": "share detected"})
        ax.set_title("D. Parish claim events detected (grey = no claim event)")
        ax.set_axis_off()
    except Exception as exc:
        ax.text(0.5, 0.5, f"map not drawn ({str(exc)[:60]})", ha="center")
        ax.set_axis_off()
    fig.tight_layout()
    fig.savefig(FIG / "fig15_nfip_validation.png", dpi=160)
    plt.close(fig)


# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-dir", default=str(PROJECT_DIR))
    ap.add_argument("--claims-file", default=None)
    args = ap.parse_args()
    set_paths(Path(args.project_dir))

    # ---- dataset ------------------------------------------------------------
    pdaily = pd.read_csv(D / "final" / f"parish_daily_{YEAR}.csv",
                         dtype={"parish_fips": str, "flood_day": "boolean"})
    pdaily["date"] = to_day(pdaily.date)
    pdaily["flood_or_big"] = pdaily.flood_day.fillna(False).astype(bool) | pdaily.big_river_flood_day.astype(bool)
    pevents = pd.read_csv(D / "final" / f"parish_events_{YEAR}.csv", dtype={"parish_fips": str})

    zdir = D / "zcta"
    have_z = (zdir / f"zcta_daily_{YEAR}.csv").exists() and (zdir / "zcta_boundaries_LA.gpkg").exists()
    zctas, neigh = set(), None
    if have_z:
        import geopandas as gpd
        zb = gpd.read_file(zdir / "zcta_boundaries_LA.gpkg")
        zb["zcta"] = zb.zcta.astype(str)
        zctas = set(zb.zcta)
        nb = gpd.sjoin(zb[["zcta", "geometry"]], zb[["zcta", "geometry"]], predicate="touches")
        neigh = nb.groupby("zcta_left").zcta_right.apply(set).to_dict()

    # ---- claims -------------------------------------------------------------
    raw = fetch_claims(args.claims_file)
    claims = clean_claims(raw, zctas)
    claims.to_csv(OUT / f"nfip_claims_{STATE}_{YEAR}_clean.csv", index=False)
    print(f"Claims in Louisiana {YEAR}: {len(claims):,}  (paid ${claims.paid.sum() / 1e6:,.1f} M; "
          f"{claims.zcta.notna().mean():.0%} with a ZIP that is a Louisiana ZCTA)")

    # ---- parish level --------------------------------------------------------
    res = []
    s, p_ce, p_ev, p_cl, p_conf, p_ann = validate_level(
        claims, pdaily, pevents, "parish_fips", "confidence", MIN_CLAIMS_PARISH,
        label="parish - local floods")
    res.append(s)
    s2, *_ = validate_level(claims, pdaily, pevents, "parish_fips", "confidence", MIN_CLAIMS_PARISH,
                            flood_col="flood_or_big", label="parish - local + big-river")
    res.append(s2)
    p_ce.to_csv(OUT / "nfip_parish_claim_events.csv", index=False)
    p_ev.drop(columns=["s", "e"]).to_csv(OUT / "nfip_parish_events_with_claims.csv", index=False)
    p_ann.to_csv(OUT / "nfip_parish_annual.csv")

    # ---- ZCTA level ----------------------------------------------------------
    z_conf = None
    if have_z:
        zdaily = pd.read_csv(zdir / f"zcta_daily_{YEAR}.csv", dtype={"zcta": str, "flood_day": "boolean"})
        zdaily["date"] = to_day(zdaily.date)
        zevents = pd.read_csv(zdir / f"zcta_events_{YEAR}.csv", dtype={"zcta": str})
        zc = claims.dropna(subset=["zcta"])
        s3, z_ce, z_ev, z_cl, z_conf, z_ann = validate_level(
            zc, zdaily, zevents, "zcta", "confidence", MIN_CLAIMS_ZCTA, neigh=neigh,
            label="ZCTA - local floods")
        res.append(s3)
        z_ce.to_csv(OUT / "nfip_zcta_claim_events.csv", index=False)
        z_ev.drop(columns=["s", "e"]).to_csv(OUT / "nfip_zcta_events_with_claims.csv", index=False)

        # ---- storm level -----------------------------------------------------
        sp = zdir / f"storms_{YEAR}.csv"
        if sp.exists():
            st = pd.read_csv(sp, dtype={"zctas": str, "parishes": str})
            tol = pd.Timedelta(days=TOL_DAYS)
            cz = zc.assign(date=pd.to_datetime(zc.date))
            n, paid, depth, used = [], [], [], set()
            for zs, s0, e0 in zip(st.zctas.fillna(""), to_day(st.start_date), to_day(st.end_date)):
                m = cz[cz.zcta.isin(zs.split(";")) & cz.date.between(s0 - tol, e0 + tol)]
                used |= set(m.claim_id)
                n.append(len(m))
                paid.append(m.paid.sum())
                depth.append(m.water_depth_in.median())
            st["nfip_claims"] = n
            st["nfip_paid_usd"] = paid
            st["nfip_median_water_depth_in"] = depth
            st.to_csv(OUT / f"storms_{YEAR}_with_claims.csv", index=False)
            share_in_storms = zc.claim_id.isin(used).mean() if len(zc) else np.nan
        else:
            st, share_in_storms = None, np.nan
    summ = pd.DataFrame(res)
    summ.to_csv(OUT / "nfip_validation_summary.csv", index=False)

    figure(claims, pdaily, p_ann, p_conf, z_conf, p_ce, D / "usgs" / "la_parishes.geojson")

    # ---- summary text ---------------------------------------------------------
    L = [f"NFIP CLAIMS VALIDATION, LOUISIANA {YEAR}", "=" * 60,
         f"Claims: {len(claims):,}; paid ${claims.paid.sum() / 1e6:,.1f} M; "
         f"ZIP matched to a Louisiana ZCTA: {claims.zcta.notna().mean():.0%}",
         f"Tolerance: +/- {TOL_DAYS} day; claim event = >= {MIN_CLAIMS_PARISH} claims/day (parish), "
         f">= {MIN_CLAIMS_ZCTA} claims/day (ZCTA)", ""]
    for _, r in summ.iterrows():
        L += [f"[{r.level}]",
              f"  Claim events on a dataset flood day : {r.claim_events_detected}/{r.claim_events} "
              f"({r.detection_rate:.0%})"
              + (f"; with neighbouring ZCTAs {r.detection_rate_with_neighbours:.0%}"
                 if "detection_rate_with_neighbours" in r and pd.notna(r.get("detection_rate_with_neighbours")) else ""),
              f"  Claims on a dataset flood day       : {r.claims_on_flood_days:,}/{r.claims_in_areas_with_data:,} "
              f"({r.share_claims_captured:.0%})",
              f"  Dataset events with >= 1 claim      : {r.dataset_events_with_claims}/{r.dataset_events} "
              f"({r.confirmation_rate:.0%})",
              f"  Rank correlation flood days vs claims (areas): {r.spearman_flood_days_vs_claims:.2f}", ""]
    L += ["Parish claim-event detection by confidence:", p_conf.round(2).to_string(), ""]
    if z_conf is not None:
        L += ["ZCTA claim-event detection by confidence:", z_conf.round(2).to_string(), ""]
    if have_z and st is not None:
        L += [f"Share of ZCTA-located claims inside a dataset storm: {share_in_storms:.0%}",
              "Storms with the most claims:",
              st.sort_values("nfip_claims", ascending=False).head(5)[
                  ["storm_id", "start_date", "end_date", "n_zctas", "event_type",
                   "nfip_claims", "nfip_paid_usd"]].to_string(index=False), ""]
    top_missed = (p_cl[~p_cl.on_flood_day].groupby("parish_fips").size()
                  .sort_values(ascending=False).head(8))
    names = pdaily.drop_duplicates("parish_fips").set_index("parish_fips").parish_name
    L += ["Parishes with the most claims NOT on a dataset flood day (urban / coastal / pluvial?):",
          ", ".join(f"{names.get(k, k)} {v}" for k, v in top_missed.items())]
    txt = "\n".join(L)
    (OUT / "nfip_validation_summary.txt").write_text(txt, encoding="utf-8")
    print(txt)
    print(f"\nOutputs in {OUT}")


if __name__ == "__main__":
    main()
