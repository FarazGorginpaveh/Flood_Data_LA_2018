"""
RUN ALL YEARS - Louisiana flood / hazard dataset for every year the data allow
==============================================================================
Runs steps 01-15 once per year and stacks the yearly results into one multi-year
dataset. The 2018 project folder is the REFERENCE: its year-independent inputs
(stream reaches, 2-year flows from 1980-2022, USGS site list and peaks, parish and
ZCTA boundaries, Atlas 14, tide-gauge list, hurricane tracks, reviewed exclusions)
are shared with every year instead of being downloaded again.

Years
  NWM v3.0 retrospective covers Feb 1979 - Jan 2023, so complete years are 1980-2022.
  Default: 1990-2021 (the health study period). USGS 15-minute data are sparse before
  about 2007, so early years rely almost entirely on the model; NWS Storm Events flood
  reports are complete from 1996 (validation only).

Layout
  <ref>\\data\\...                  the finished 2018 run, read only (default ...\\Sepideh_2)
  <root>\\years\\<YYYY>\\data\\...    one complete project folder per year (default ...\\Sepideh_3)
  <root>\\all_years\\                stacked results incl. 2018 (MASTER, county, storms, daily)

How each year is run
  Every script reads the year and the project folder from two settings, FLOOD_YEAR
  and FLOOD_PROJECT_DIR, which this driver sets. Steps whose main output already
  exists are skipped (use --force to redo), so the driver can be stopped and restarted.
    01 (USGS 15-min + daily for the year)   03 (NWM hourly for the year + check)
    05 events   06 evaluation   07 parish tables   07b diagnosis (for review)
    08 NWS reports   09 ZCTA tables   10 storms   11 NFIP claims
    12 rainfall   13 coastal + cyclones   14 all-hazard table   15 MASTER + workbook
  Manual review: the 2018 reviewed exclusions are applied to every year (they are
  mostly permanent features: tidal marsh, a lake, a pump-fed bayou). Step 07b still
  writes each year's long-block diagnosis to data\\diagnostics\\ for checking.
  Confidence: if a year has fewer than MIN_GAUGES evaluated USGS gauges (common
  before ~2007), the 2018 county confidence levels are used and logged.

Usage
  python run_all_years.py                                  # 1990-2021, 10- and 25-year floods
  python run_all_years.py --years 2016 2017 2019           # chosen years
  python run_all_years.py --years 1980-2022                # every complete year
  python run_all_years.py --steps 12 13 14 15              # only some steps
  python run_all_years.py --combine-only                   # just stack finished years
  python run_all_years.py --dry-run                        # show what would run
  python run_all_years.py --zcta-vintage auto              # ZCTAs of the time (2000/2010/2020)
  python run_all_years.py --return-period 10 25            # 10- and 25-year flood datasets
                                                           # (in <root>\\Q10 and <root>\\Q25)
Needs: USGS_API_KEY set (step 01), the finished 2018 run in <ref>\\data (default ...\\Sepideh_2).
Time : roughly 1-3 hours per year (mostly downloads); run in batches if needed.
"""

import argparse
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import pandas as pd

ROOT_DEFAULT = Path(r"D:\Tufts\Wishlist\Sepideh_3")      # where all new years go
REF_DEFAULT = Path(r"D:\Tufts\Wishlist\Sepideh_2")       # the finished 2018 run (read only)
SCRIPTS_DEFAULT = Path(__file__).resolve().parent
REF_YEAR = 2018
STATE = "LA"
MIN_GAUGES = 10
FIRST_YEAR, LAST_YEAR = 1980, 2022          # complete years of the NWM v3.0 retrospective

# year-independent inputs shared from the reference run (relative to <root>\data)
SHARED_FILES = [
    "usgs/sites_LA.csv", "usgs/timeseries_metadata_LA.csv", "usgs/thresholds_LA.csv",
    "usgs/annual_peaks_LA.csv", "usgs/la_parishes.geojson",
    "nwm/reaches_LA.csv", "nwm/reach_thresholds_LA.csv", "nwm/annual_max_LA.parquet",
    "diagnostics/reviewed_exclusions.csv",
    "rain/atlas14_zcta.csv", "coastal/coops_stations_LA.csv",
]
SHARED_DIRS = ["zcta/census", "hurdat"]

# raw downloads of ONE year that do not depend on the flood threshold: when the same year
# already exists (2-year run, or the 2018 reference), they are shared instead of downloaded
RAW_YEAR_FILES = [
    "usgs/continuous_manifest.csv", "usgs/daily_discharge_LA.parquet", "usgs/parish_coverage.csv",
    "nwm/nwm_LA_hourly_{Y}.complete", "nwm/nwm_vs_usgs_{Y}_stats.csv", "nwm/usgs_nwm_crosswalk_LA.csv",
    "rain/zcta_rain_hourly_{Y}.parquet", "rain/zcta_rain_daily_{Y}.csv",
    "coastal/coops_daily_max_{Y}.csv", "coastal/coops_no_data_{Y}.txt",
    "coastal/zcta_coastal_daily_{Y}.csv", "coastal/hurricane_zcta_{Y}.csv",
    "validation/storm_events_LA_{Y}.csv", "nfip/nfip_claims_LA_{Y}.csv", "nfip/nfip_claims_LA_{Y}_clean.csv",
]
RAW_YEAR_DIRS = ["usgs/continuous", "nwm/nwm_LA_hourly_{Y}.zarr", "stormevents"]
# of these, the ones tied to the ZCTA set (re-computed when the ZCTA boundaries differ)
ZCTA_DEPENDENT = {"rain/zcta_rain_hourly_{Y}.parquet", "rain/zcta_rain_daily_{Y}.csv",
                  "coastal/zcta_coastal_daily_{Y}.csv", "coastal/hurricane_zcta_{Y}.csv",
                  "nfip/nfip_claims_LA_{Y}_clean.csv"}

# step -> (script, extra args, main output relative to the year's data folder)
STEPS = {
    "01": ("01_download_usgs_streamflow.py", ["--steps", "3", "4", "6"], "usgs/continuous_manifest.csv"),
    "03": ("03_download_nwm_retrospective.py", ["--steps", "2", "4"], "nwm/nwm_LA_hourly_{Y}.complete"),
    "05": ("05_extract_flood_events.py", [], "events/events_nwm_{Y}.parquet"),
    "06": ("06_evaluate_nwm.py", [], "evaluation/parish_confidence_{Y}.csv"),
    "07": ("07_parish_dataset.py", [], "final/parish_daily_{Y}.csv"),
    "07b": ("07b_diagnose_long_blocks.py", [], "diagnostics/long_blocks_{Y}.csv"),
    "08": ("08_validate_storm_events.py", [], "validation/validation_summary.txt"),
    "09": ("09_zcta_dataset.py", [], "zcta/zcta_events_{Y}.csv"),
    "10": ("10_enrich_zcta_events.py", [], "zcta/zcta_events_{Y}_enriched.csv"),
    "11": ("11_validate_nfip_claims.py", [], "nfip/nfip_validation_summary.txt"),
    "12": ("12_rainfall_aorc.py", [], "rain/zcta_rain_daily_{Y}.csv"),
    "13": ("13_coastal_hurricane.py", [], "coastal/zcta_coastal_daily_{Y}.csv"),
    "14": ("14_final_event_zcta_table.py", [], "final_zcta/hazard_events_zcta_LA_{Y}.csv"),
    "15": ("15_comprehensive_file.py", ["--no-daily"], "deliverable/MASTER_event_zcta_LA_{Y}.csv"),
}
OPTIONAL = {"01", "07b", "08", "11"}         # a failure here does not stop the year
                                             # (01: the model-based steps work without USGS data)


def usgs_key_available(scripts_dir):
    """True if the key is set in this session OR pasted into step 01's API_KEY line."""
    if os.environ.get("USGS_API_KEY"):
        return True
    import re
    try:
        src = (scripts_dir / STEPS["01"][0]).read_text(encoding="utf-8")
    except OSError:
        return False
    m = re.search(r'^API_KEY\s*=\s*os\.environ\.get\(\s*"USGS_API_KEY"\s*,\s*"([^"]*)"', src, re.M) or \
        re.search(r'^API_KEY\s*=\s*"([^"]+)"', src, re.M)
    return bool(m and m.group(1).strip())


def parse_years(items):
    years = []
    for it in items:
        if "-" in str(it):
            a, b = str(it).split("-")
            years += list(range(int(a), int(b) + 1))
        else:
            years.append(int(it))
    bad = [y for y in years if not FIRST_YEAR <= y <= LAST_YEAR]
    if bad:
        print(f"  ! skipping {bad}: outside {FIRST_YEAR}-{LAST_YEAR} (NWM v3.0 retrospective)")
    return sorted(set(y for y in years if FIRST_YEAR <= y <= LAST_YEAR))


def share(src, dst):
    """Hard link (no extra disk space, no admin rights on NTFS); copy if that fails."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    try:
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)


def prepare_year(ref_root, ydir, log):
    ref = ref_root / "data"
    missing = []
    for rel in SHARED_FILES:
        src = ref / rel
        if src.exists():
            share(src, ydir / "data" / rel)
        else:
            missing.append(rel)
    for rel in SHARED_DIRS:
        src = ref / rel
        if src.exists():
            for f in src.rglob("*"):
                if f.is_file():
                    share(f, ydir / "data" / rel / f.relative_to(src))
        else:
            missing.append(rel + "/")
    if missing:
        log(f"  note: not in the reference run (will be created or downloaded): {', '.join(missing)}")


def share_raw_year(donor, ydir, year, log, same_zctas=True):
    """Reuse threshold-independent downloads of this year from an earlier run
    (only the ZCTA-independent ones when the ZCTA boundaries differ)."""
    if donor is None or not donor.exists() or donor.resolve() == (ydir / "data").resolve():
        return
    n = 0
    for rel in RAW_YEAR_FILES:
        if not same_zctas and rel in ZCTA_DEPENDENT:
            continue
        src = donor / rel.format(Y=year)
        if src.exists():
            share(src, ydir / "data" / rel.format(Y=year))
            n += 1
    for rel in RAW_YEAR_DIRS:
        src = donor / rel.format(Y=year)
        if src.exists():
            for f in src.rglob("*"):
                if f.is_file():
                    share(f, ydir / "data" / rel.format(Y=year) / f.relative_to(src))
            n += 1
    if n:
        log(f"  {year}: reused {n} downloaded inputs from {donor}")


def confidence_fallback(root, ydir, year, log):
    """Use the reference-year county confidence when a year has too few evaluated gauges."""
    ev = ydir / "data" / "evaluation" / f"gauge_evaluation_{year}.csv"
    n = 0
    if ev.exists():
        g = pd.read_csv(ev)
        n = int((g.get("skill", pd.Series(dtype=str)) != "crosswalk_error").sum())
    if n >= MIN_GAUGES:
        return
    ref = root / "data" / "evaluation" / f"parish_confidence_{REF_YEAR}.csv"   # root = the reference folder here
    if ref.exists():
        shutil.copy2(ref, ydir / "data" / "evaluation" / f"parish_confidence_{year}.csv")
        log(f"  {year}: only {n} evaluated gauges -> using the {REF_YEAR} county confidence levels")


def run_year(year, args, log, T=2, vintage="2020"):
    ydir = args.root / "years" / str(year)
    (ydir / "data").mkdir(parents=True, exist_ok=True)
    prepare_year(args.ref, ydir, log)
    if T != 2 or vintage != "2020":   # reuse this year's downloads from the main run (or the 2018 reference)
        donor = args.ref / "data" if (year == REF_YEAR and not (args.base / "years" / str(year)).exists()) \
            else args.base / "years" / str(year) / "data"
        same = vintage == "2020" or (vintage == "auto" and year >= 2015)
        share_raw_year(donor, ydir, year, log, same_zctas=same)
    env = dict(os.environ, FLOOD_YEAR=str(year), FLOOD_PROJECT_DIR=str(ydir),
               FLOOD_RETURN_PERIOD=str(T), FLOOD_ZCTA_VINTAGE=str(vintage),
               PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1")   # unbuffered: logs fill while a step runs
    status = {}
    for step in args.steps:
        script, extra, out = STEPS[step]
        out_path = ydir / "data" / out.format(Y=year)
        if out_path.exists() and not args.force:
            status[step] = "done before"
            continue
        cmd = [sys.executable, str(args.scripts / script), *extra]
        if args.dry_run:
            log(f"  [dry-run] {year} {step}: {' '.join(cmd)}")
            status[step] = "dry-run"
            continue
        t0 = time.time()
        logf = ydir / f"log_step{step}.txt"
        with open(logf, "w", encoding="utf-8") as fh:
            r = subprocess.run(cmd, env=env, stdout=fh, stderr=subprocess.STDOUT, cwd=str(ydir))
        mins = (time.time() - t0) / 60
        if r.returncode == 0:
            status[step] = f"ok ({mins:.0f} min)"
            log(f"  {year} step {step}: ok in {mins:.1f} min")
            if step == "06":
                confidence_fallback(args.ref, ydir, year, log)
        else:
            status[step] = f"FAILED (see {logf.name})"
            log(f"  {year} step {step}: FAILED after {mins:.1f} min - see {logf}")
            if step not in OPTIONAL:
                log(f"  {year}: later steps skipped (they need step {step})")
                break
    return status


# ----------------------------------------------------------------------------
def combine(root, ref_root, years, log, T=2):
    out = root / "all_years"
    out.mkdir(exist_ok=True)
    tables = {
        "MASTER_event_zcta": "deliverable/MASTER_event_zcta_LA_{Y}.csv",
        "County_events": "deliverable/csv/County_events_LA_{Y}.csv",
        "Storms": "deliverable/csv/Storms_LA_{Y}.csv",
        "ZCTA_daily": "deliverable/csv/ZCTA_daily_LA_{Y}.csv",
        "County_daily": "deliverable/csv/County_daily_LA_{Y}.csv",
    }
    all_years = sorted(set(years) | {REF_YEAR})
    for name, rel in tables.items():
        frames = []
        for y in all_years:
            base = ref_root / "data" if (T == 2 and y == REF_YEAR and not (root / "years" / str(y)).exists()) \
                else root / "years" / str(y) / "data"     # T = -1: never take 2018 from the reference
            p = base / rel.format(Y=y)
            if p.exists():
                df = pd.read_csv(p, dtype={"zcta": str, "county_fips": str}, low_memory=False)
                df.insert(0, "year", y)
                frames.append(df)
        if not frames:
            continue
        df = pd.concat(frames, ignore_index=True)
        yrs = f"{df.year.min()}_{df.year.max()}" + ("" if T in (2, -1) else f"_Q{T}") + \
            (f"_{root.name}" if T == -1 else "")
        if name.endswith("daily"):
            try:
                df.to_parquet(out / f"{name}_{STATE}_{yrs}.parquet", index=False)
            except Exception:
                df.to_csv(out / f"{name}_{STATE}_{yrs}.csv.gz", index=False, compression="gzip")
        else:
            df.to_csv(out / f"{name}_{STATE}_{yrs}.csv", index=False)
        log(f"  combined {name}: {len(df):,} rows, {df.year.nunique()} years -> {out}")
    ref_dict = ref_root / "data" / "deliverable" / "csv" / f"Dictionary_{STATE}_{REF_YEAR}.csv"
    if ref_dict.exists():
        d = pd.read_csv(ref_dict)
        extra = pd.DataFrame([{"sheet": "all", "variable": "year", "description": "Calendar year of the event file",
                               "unit": "year", "type_or_format": "integer", "missingness": "never missing"}])
        pd.concat([extra, d], ignore_index=True).to_csv(
            out / f"Dictionary_{STATE}_all_years{'' if T == 2 else f'_Q{T}'}.csv", index=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--years", nargs="*", default=["1990-2021"])
    ap.add_argument("--root", type=Path, default=ROOT_DEFAULT, help="output folder for all years (new)")
    ap.add_argument("--ref", type=Path, default=REF_DEFAULT, help="folder of the finished 2018 run (read only)")
    ap.add_argument("--scripts", type=Path, default=SCRIPTS_DEFAULT, help="folder with the step scripts")
    ap.add_argument("--steps", nargs="*", default=list(STEPS), choices=list(STEPS))
    ap.add_argument("--force", action="store_true", help="redo steps whose output already exists")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--combine-only", action="store_true")
    ap.add_argument("--zcta-vintage", nargs="*", default=["2020"], choices=["2020", "2010", "2000", "auto"],
                    help="ZCTA boundaries: 2020 (default), 2010, 2000, or auto (<=2004: 2000 ZCTAs, "
                         "2005-2014: 2010 ZCTAs, >=2015: 2020 ZCTAs). Non-2020 runs go to their own folder")
    ap.add_argument("--return-period", nargs="*", type=int, default=[10, 25],
                    help="flood threshold(s): streams flood above their T-year flow. Default: 10 and 25 "
                         "(two datasets); add 2 for the original 2-year dataset, e.g. 2 10 25. "
                         "T = 2 goes to <root>; any other T to <root>\\Q<T> (separate dataset)")
    args = ap.parse_args()
    years = parse_years(args.years)
    args.root.mkdir(parents=True, exist_ok=True)
    if not (args.ref / "data").exists():
        sys.exit(f"Reference run not found: {args.ref / 'data'} - pass --ref with the 2018 project folder")

    base = args.root
    for T in args.return_period:
        if T < 2:
            sys.exit("--return-period must be 2 or more")
        for v in args.zcta_vintage:
            parts = ([f"Q{T}"] if T != 2 else []) + ([f"ZCTA{v}"] if v != "2020" else [])
            args.base = base
            args.root = base / "_".join(parts) if parts else base
            args.root.mkdir(parents=True, exist_ok=True)
            run_threshold(args, years, T, v)
    args.root = base


def run_threshold(args, years, T, vintage="2020"):
    logfile = args.root / "run_all_years_log.txt"

    def log(msg):
        line = f"{time.strftime('%Y-%m-%d %H:%M')}  {msg}"
        print(line, flush=True)
        with open(logfile, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")

    if not args.combine_only:
        if "01" in args.steps and not args.dry_run and not usgs_key_available(args.scripts):
            log("  ! no USGS API key found (not set in this session and not pasted in step 01) - "
                "step 01 will be slow or rate-limited")
        log(f"Flood threshold: {T}-year flow; ZCTA boundaries: {vintage} -> {args.root}")
        log(f"Running years {years[0]}-{years[-1]} ({len(years)} years), steps {' '.join(args.steps)}")
        rows = []
        for y in years:
            if T == 2 and vintage in ("2020", "auto") and y == REF_YEAR and (args.ref / "data" / "deliverable").exists():
                log(f"  {y}: reference year, already done in {args.ref / 'data'}")
                continue
            log(f"=== {y} (threshold {T}-year) ===")
            st = run_year(y, args, log, T, vintage)
            rows.append({"year": y, "return_period": T, "zcta_vintage": vintage, **st})
            pd.DataFrame(rows).to_csv(args.root / "run_all_years_status.csv", index=False)
    if not args.dry_run:
        combine(args.root, args.ref, years, log, T if vintage in ("2020", "auto") else -1)
    log(f"Finished threshold {T}-year. Status: run_all_years_status.csv; combined files: all_years\\")


if __name__ == "__main__":
    main()
