"""
Find the Louisiana 2018 flood project after moving folders.

Searches drives (or the folders you give) for the project's key files and folders,
lists them NEWEST FIRST, and guesses the new project root (the folder that holds
data\\deliverable, data\\nwm, data\\zcta ...). Read-only: nothing is moved or changed.

Usage (Spyder or Anaconda Prompt):
    python find_project_files.py                 # searches all drives (can take a few minutes)
    python find_project_files.py D:\\ E:\\        # only these places (faster)
"""

import os
import string
import sys
import time
from collections import Counter
from pathlib import Path

# most important outputs first
KEY_FILES = [
    "MASTER_event_zcta_LA_2018.csv", "Event_zcta_LA_2018.csv", "LA_2018_flood_hazard_dataset.xlsx",
    "hazard_events_zcta_LA_2018.csv", "flood_events_zcta_LA_2018.csv", "zcta_daily_exposure_LA_2018.csv",
    "zcta_universe_LA_2018.csv", "data_dictionary_LA_2018.csv", "County_events_LA_2018.csv",
    "Storms_LA_2018.csv", "zcta_events_2018_enriched.csv", "storms_2018.csv", "parish_daily_2018.csv",
    "parish_events_2018.csv", "parish_annual_2018.csv", "reviewed_exclusions.csv",
    "reach_thresholds_LA.csv", "reaches_LA.csv", "events_nwm_2018.parquet", "zcta_rain_daily_2018.csv",
    "hurricane_zcta_2018.csv", "nfip_validation_summary.txt", "validation_summary.txt", "sites_LA.csv",
]
KEY_DIRS = ["nwm_LA_hourly_2018.zarr"]                       # folders, not files
SCRIPT_HINTS = ("15_comprehensive_file", "14_final_event_zcta_table", "untitled")
PROJECT_SUBFOLDERS = {"usgs", "nwm", "events", "evaluation", "final", "zcta", "final_zcta",
                      "deliverable", "rain", "coastal", "nfip", "validation", "diagnostics"}
SKIP = {"windows", "program files", "program files (x86)", "$recycle.bin", "appdata",
        "system volume information", "programdata", "anaconda3", "miniconda3", ".git", "node_modules"}


def roots_from_args():
    if len(sys.argv) > 1:
        return [Path(a) for a in sys.argv[1:]]
    if os.name == "nt":
        return [Path(f"{d}:\\") for d in string.ascii_uppercase if Path(f"{d}:\\").exists()]
    return [Path.home()]


def main():
    found, dirs, scripts, data_dirs = [], [], [], Counter()
    t0 = time.time()
    for root in roots_from_args():
        print(f"Searching {root} ...")
        for cur, subdirs, files in os.walk(root, topdown=True):
            subdirs[:] = [d for d in subdirs if d.lower() not in SKIP and not d.startswith(".")]
            p = Path(cur)
            for d in list(subdirs):
                if d in KEY_DIRS:
                    dirs.append(p / d)
                    subdirs.remove(d)                       # do not walk inside the zarr store
            if p.name.lower() == "data" and len(PROJECT_SUBFOLDERS & {d.lower() for d in subdirs}) >= 3:
                data_dirs[p.parent] += len(PROJECT_SUBFOLDERS & {d.lower() for d in subdirs})
            for f in files:
                if f in KEY_FILES:
                    found.append(p / f)
                elif f.endswith(".py") and any(h in f for h in SCRIPT_HINTS):
                    scripts.append(p / f)

    def show(title, paths, n=40):
        print(f"\n{title}")
        if not paths:
            print("  (none found)")
            return
        rows = []
        for x in paths:
            try:
                st = x.stat()
                rows.append((st.st_mtime, st.st_size, x))
            except OSError:
                pass
        for mt, size, x in sorted(rows, reverse=True)[:n]:
            print(f"  {time.strftime('%Y-%m-%d %H:%M', time.localtime(mt))}  {size / 1e6:8.1f} MB  {x}")

    print("\nLIKELY PROJECT ROOT(S) (folder that contains data\\ with the project subfolders):")
    if data_dirs:
        for root, score in data_dirs.most_common(5):
            print(f"  {root}   ({score} project subfolders in data\\)")
        print("  -> set PROJECT_DIR = Path(r\"<that folder>\") at the top of each script")
    else:
        print("  (none found - try giving the drive or folder as an argument)")
    show("KEY FILES, newest first:", found)
    show("NWM hourly store:", dirs, 5)
    show("SCRIPTS (step 14/15 and Spyder 'untitled' files), newest first:", scripts, 25)
    print(f"\nDone in {(time.time() - t0) / 60:.1f} min.")


if __name__ == "__main__":
    main()
