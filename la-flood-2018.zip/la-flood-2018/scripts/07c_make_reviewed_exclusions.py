"""
STEP 7c - Create reviewed_exclusions.csv from the step 7b suggestions
=====================================================================
Applies the manual review of the long flood blocks:
  * keep   : Caldwell 'stuck' reaches = the real Ouachita River flood (Feb-Mar 2018)
  * move   : Atchafalaya / Wax Lake gauges -> separate big-river category
  * add    : Bayou Lafourche gauges in Ascension (pump-fed from the Mississippi)
  * exclude: everything else suggested (coastal marsh, Pearl River mouth,
             Vernon lake reaches, Ouachita headwater reaches, GIWW gauge)

Usage: python 07c_make_reviewed_exclusions.py   (then run 07_parish_dataset.py)
"""
import os
from pathlib import Path

import pandas as pd

DIAG = Path(os.environ.get("FLOOD_PROJECT_DIR", r"D:\Tufts\Wishlist\Sepideh_3")) / "data" / "diagnostics"

ex = pd.read_csv(DIAG / "suggested_exclusions.csv", dtype={"id": str, "parish_fips": str})
ex = ex[~((ex.parish_fips == "22021") & (ex.reason == "stuck"))].copy()   # keep Caldwell
ex["decision"] = "exclude"
ex.loc[ex.reason == "big-river backwater", "decision"] = "separate big-river category"

manual = pd.DataFrame([
    {"type": "usgs_gauge", "id": g, "parish_fips": "22005",
     "reason": "regulated (pump-fed from Mississippi River)", "block": "2018 review (3 blocks)",
     "decision": "exclude"}
    for g in ("USGS-07380400_00060", "USGS-07380401_00060")])

out = pd.concat([ex, manual], ignore_index=True).drop_duplicates("id")
out.to_csv(DIAG / "reviewed_exclusions.csv", index=False)
print(out.groupby(["type", "decision"]).size().to_string())
print(f"\nSaved {len(out)} rows -> {DIAG / 'reviewed_exclusions.csv'}")
