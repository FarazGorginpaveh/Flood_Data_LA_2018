"""
STEP 16 - PILOT: flood depth and flooded area for one event (NOAA OWP HAND-FIM)
==============================================================================
Tests whether depth / extent maps are credible before doing all events.

Event   : the late-February 2018 flood (the storm whose dates contain 26 Feb 2018 and
          that covers the most ZCTAs), around Bossier and Caddo parishes (Red River).
Method  : NOAA OWP HAND-FIM, run with the FIMserv package (Baruah et al. 2025,
          Environmental Modelling & Software 192:106581):
            1. find the HUC8 watershed(s) covering the pilot ZCTAs
            2. peak NWM flow of every reach during the event, from YOUR step 3 file
               (data/nwm/nwm_LA_hourly_2018.zarr) - same flows as the rest of the dataset
            3. FIMserv downloads the watershed's HAND rasters and rating curves (public
               CIROH bucket, no account) and maps inundation EXTENT and DEPTH (10 m)
            4. per ZCTA: flooded area and share, max / mean / 90th-percentile depth,
               population-weighted depth and share of people in flooded cells
               (2020 Census blocks)
            5. check against FEMA NFIP claims (step 11): are claims in the flooded ZCTAs,
               and how do reported water depths compare?

Setup (one time) - FIMserv needs git, the AWS command line and GDAL. The easiest way:
    conda create -n fimserve -c conda-forge python=3.10 gdal git geopandas rasterio xarray zarr
    conda activate fimserve
    pip install fimserve
  then run this script from that environment:
    python 16_flood_depth_pilot.py
  If FIMserv does not work on Windows, run the same script in Google Colab or on Linux,
  or run the HAND step there and use  --skip-hand  here with the rasters copied into
  data/depth_pilot/hand/output/...

Outputs (data/depth_pilot/)
  zcta_depth_pilot_<storm>.csv    per ZCTA: flooded area and share, depths, population measures
  nwm_peak_<storm>_<huc>.csv      peak flow per reach used for the maps
  depth_pilot_summary.txt, figures/fig18_depth_pilot.png
  hand/output/flood_<huc>/<huc>_inundation/*_depth.tif and *_inundation.tif (the rasters)

NOTE: HAND works best where rivers sit in valleys. Louisiana is flat, and NOAA masks
levee-protected areas and lakes. Read the results together with the NFIP check.
"""

import argparse
import io
import json
import os
import zipfile
from pathlib import Path

import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import requests

# ----------------------------------------------------------------------------
# CONFIGURATION
# ----------------------------------------------------------------------------
PROJECT_DIR = Path(r"D:\Tufts\Wishlist\Sepideh_3")
YEAR = 2018
PILOT_DAY = "2018-02-26"              # main day of the late-February flood
PILOT_COUNTIES = ["22015", "22017"]   # Bossier, Caddo
MAX_HUCS = 2                          # watersheds to map in the pilot (largest overlap first)
MIN_HUC_OVERLAP = 5                   # % of the pilot area a HUC8 must cover
MIN_COVERAGE = 0.5                    # ZCTA reported if >= 50% of it lies in the mapped HUC8s
HAND_VERSION = None                   # None = latest HAND rasters hosted by FIMserv
HUC8_REST = ("https://services.arcgis.com/ts4gk3YgS68yLGFl/arcgis/rest/services/"
             "HUC8_Boundaries/FeatureServer/0/query")
BLOCKS_URL = "https://www2.census.gov/geo/tiger/TIGER2020/TABBLOCK20/tl_2020_22_tabblock20.zip"
EQUAL_AREA = 5070                     # CONUS Albers (the CRS of the HAND rasters)


def set_paths(project_dir):
    global D, OUT, HAND, FIG
    D = project_dir / "data"
    OUT = D / "depth_pilot"
    HAND = OUT / "hand"
    FIG = OUT / "figures"
    for p in (HAND, FIG):
        p.mkdir(parents=True, exist_ok=True)


def day(x):
    return pd.to_datetime(pd.Series(x).astype(str).str[:10], errors="coerce")


# ----------------------------------------------------------------------------
# 1. PILOT EVENT AND ZCTAs
# ----------------------------------------------------------------------------
def pilot_event(storm_arg):
    ev = pd.read_csv(D / "final_zcta" / f"hazard_events_zcta_LA_{YEAR}.csv",
                     dtype={"zcta": str, "main_parish_fips": str})
    ev["s"], ev["e"] = day(ev.start_date), day(ev.end_date)
    if storm_arg:
        sid = storm_arg
    else:
        pd_ = pd.Timestamp(PILOT_DAY)
        cand = ev[(day(ev.storm_start_date) <= pd_) & (day(ev.storm_end_date) >= pd_)]
        sid = cand.groupby("storm_id").zcta.nunique().idxmax()
    g = ev[ev.storm_id == sid]
    win = (g.s.min() - pd.Timedelta(days=1), g.e.max() + pd.Timedelta(days=1))
    z = g[g.main_parish_fips.isin(PILOT_COUNTIES)]
    print(f"Pilot event {sid}: {win[0]:%d %b} - {win[1]:%d %b %Y}; "
          f"{g.zcta.nunique()} ZCTAs in the event, {z.zcta.nunique()} in the pilot counties")
    return sid, win, g, z


# ----------------------------------------------------------------------------
# 2. HUC8 WATERSHEDS
# ----------------------------------------------------------------------------
def pilot_hucs(area_4326):
    minx, miny, maxx, maxy = area_4326.total_bounds
    params = {"f": "geojson", "where": "1=1",
              "geometry": json.dumps({"xmin": minx, "ymin": miny, "xmax": maxx, "ymax": maxy,
                                      "spatialReference": {"wkid": 4326}}),
              "geometryType": "esriGeometryEnvelope", "spatialRel": "esriSpatialRelIntersects",
              "inSR": 4326, "outFields": "HUC8,name", "returnGeometry": "true", "outSR": 4326}
    r = requests.post(HUC8_REST, data=params, timeout=60)
    r.raise_for_status()
    h = gpd.read_file(io.BytesIO(r.content))
    ha, aa = h.to_crs(EQUAL_AREA), area_4326.to_crs(EQUAL_AREA).union_all() \
        if hasattr(area_4326, "union_all") else area_4326.to_crs(EQUAL_AREA).unary_union
    h["overlap_pct"] = [100 * g.intersection(aa).area / aa.area for g in ha.geometry]
    h = h[h.overlap_pct >= MIN_HUC_OVERLAP].sort_values("overlap_pct", ascending=False)
    h.to_file(OUT / "pilot_huc8.gpkg", driver="GPKG")
    print("HUC8 watersheds over the pilot area:")
    print(h[["HUC8", "name", "overlap_pct"]].round(1).to_string(index=False))
    return h.head(MAX_HUCS)


# ----------------------------------------------------------------------------
# 3. PEAK NWM FLOW PER REACH (from step 3)
# ----------------------------------------------------------------------------
def peak_flows(win, sid, hucs):
    import xarray as xr
    z = xr.open_zarr(D / "nwm" / "nwm_LA_hourly_2018.zarr")
    t0 = (win[0] + pd.Timedelta(hours=6)).tz_localize(None)       # local -> UTC (approx.)
    t1 = (win[1] + pd.Timedelta(hours=30)).tz_localize(None)
    q = z["streamflow"].sel(time=slice(t0, t1)).max("time").compute()
    peaks = pd.DataFrame({"feature_id": q.feature_id.values.astype("int64"),
                          "discharge": np.round(q.values.astype(float), 3)}).dropna()
    files = {}
    inputs = HAND / "data" / "inputs"
    inputs.mkdir(parents=True, exist_ok=True)
    for huc in hucs.HUC8:
        p = inputs / f"nwm_peak_{sid}_{huc}.csv"         # FIMserv picks files with the HUC in the name
        peaks.to_csv(p, index=False)
        peaks.to_csv(OUT / p.name, index=False)
        files[huc] = p
    print(f"Peak flows for {len(peaks):,} Louisiana reaches written "
          f"(reaches outside Louisiana get no flow -> no mapping there)")
    return files


# ----------------------------------------------------------------------------
# 4. RUN HAND-FIM (FIMserv)
# ----------------------------------------------------------------------------
def run_hand(hucs, files):
    import fimserve as fm
    here = os.getcwd()
    os.chdir(HAND)                        # FIMserv works relative to the current folder
    try:
        for huc in hucs.HUC8:
            print(f"\n--- HUC8 {huc}: downloading HAND data (several GB the first time) ---")
            fm.DownloadHUC8(huc, version=HAND_VERSION)
            print(f"--- HUC8 {huc}: mapping extent and depth ---")
            fm.runOWPHANDFIM(huc, depth=True)
    finally:
        os.chdir(here)


def raster_paths(hucs, sid):
    out = {}
    for huc in hucs.HUC8:
        d = HAND / "output" / f"flood_{huc}" / f"{huc}_inundation"
        dep = d / f"nwm_peak_{sid}_{huc}_depth.tif"
        ext = d / f"nwm_peak_{sid}_{huc}_inundation.tif"
        if dep.exists():
            out[huc] = (dep, ext)
        else:
            print(f"  ! no depth raster for {huc} at {dep}")
    return out


# ----------------------------------------------------------------------------
# 5. ZCTA STATISTICS
# ----------------------------------------------------------------------------
def load_blocks(zb_area):
    cache = OUT / "tl_2020_22_tabblock20.zip"
    if not cache.exists():
        print("Downloading 2020 Census blocks for Louisiana (population) ...")
        r = requests.get(BLOCKS_URL, timeout=600)
        r.raise_for_status()
        cache.write_bytes(r.content)
    b = gpd.read_file(f"zip://{cache}", bbox=tuple(zb_area.to_crs(4269).total_bounds))
    b = b[pd.to_numeric(b.POP20, errors="coerce").fillna(0) > 0]
    pts = gpd.GeoDataFrame({"pop": pd.to_numeric(b.POP20)},
                           geometry=gpd.points_from_xy(pd.to_numeric(b.INTPTLON20),
                                                       pd.to_numeric(b.INTPTLAT20)), crs=4269)
    return pts.to_crs(EQUAL_AREA)


def zcta_stats(zpoly, rasters, blocks, hucs_geom):
    import rasterio
    from rasterio.mask import mask as rmask
    rows = []
    hu = hucs_geom.to_crs(EQUAL_AREA).union_all() if hasattr(hucs_geom, "union_all") \
        else hucs_geom.to_crs(EQUAL_AREA).unary_union
    zp = zpoly.to_crs(EQUAL_AREA)
    srcs = {h: rasterio.open(p[0]) for h, p in rasters.items()}
    for _, r in zp.iterrows():
        geom = r.geometry
        cov = geom.intersection(hu).area / geom.area if geom.area else 0
        if cov < MIN_COVERAGE:
            continue
        cells, depths = 0, []
        px_area = None
        for src in srcs.values():
            try:
                arr, _ = rmask(src, [geom], crop=True, filled=True, nodata=np.nan)
            except ValueError:            # ZCTA outside this raster
                continue
            a = arr[0].astype(float)
            if src.nodata is not None:
                a[a == src.nodata] = np.nan
            a[a <= 0] = np.nan
            px_area = abs(src.res[0] * src.res[1])
            d = a[np.isfinite(a)]
            depths.append(d)
            cells += len(d)
        d = np.concatenate(depths) if depths else np.array([])
        flooded_km2 = cells * (px_area or 0) / 1e6
        rec = {"zcta": r.zcta, "county_fips": r.main_parish_fips, "zcta_area_km2": round(geom.area / 1e6, 2),
               "hand_coverage_share": round(cov, 3),
               "flooded_area_km2": round(flooded_km2, 3),
               "flooded_share": round(flooded_km2 / (geom.area / 1e6 * cov), 4) if cov else np.nan,
               "depth_max_m": round(float(d.max()), 2) if len(d) else 0.0,
               "depth_mean_m": round(float(d.mean()), 2) if len(d) else 0.0,
               "depth_p90_m": round(float(np.percentile(d, 90)), 2) if len(d) else 0.0}
        # population measures (blocks' internal points)
        if blocks is not None and len(blocks):
            bp = blocks[blocks.within(geom)]
            if len(bp):
                bd = np.zeros(len(bp))
                for src in srcs.values():
                    xy = [(p.x, p.y) for p in bp.geometry]
                    v = np.array([x[0] for x in src.sample(xy)], dtype=float)
                    v[~np.isfinite(v) | (v < 0)] = 0
                    if src.nodata is not None:
                        v[v == src.nodata] = 0
                    bd = np.maximum(bd, v)
                pop = bp["pop"].to_numpy(float)
                rec.update({"population": int(pop.sum()),
                            "pop_share_flooded": round(float(pop[bd > 0].sum() / pop.sum()), 4),
                            "depth_popweighted_m": round(float((bd * pop).sum() / pop.sum()), 3),
                            "depth_popweighted_flooded_m": round(float((bd[bd > 0] * pop[bd > 0]).sum()
                                                                       / pop[bd > 0].sum()), 3)
                            if (bd > 0).any() else 0.0})
        rows.append(rec)
    for s in srcs.values():
        s.close()
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------
# 6. NFIP CHECK AND FIGURE
# ----------------------------------------------------------------------------
def nfip_check(stats, win):
    p = D / "nfip" / f"nfip_claims_LA_{YEAR}_clean.csv"
    if not p.exists() or stats.empty:
        return stats, "NFIP claims not found (run step 11) - no check."
    c = pd.read_csv(p, dtype={"zcta": str})
    c["date"] = day(c.date)
    c = c[(c.date >= win[0]) & (c.date <= win[1]) & c.zcta.isin(stats.zcta)]
    g = c.groupby("zcta").agg(nfip_claims=("claim_id", "size"),
                              nfip_depth_median_in=("water_depth_in", "median"))
    stats = stats.merge(g, on="zcta", how="left")
    stats["nfip_claims"] = stats.nfip_claims.fillna(0).astype(int)
    with_c, without = stats[stats.nfip_claims > 0], stats[stats.nfip_claims == 0]
    lines = [f"NFIP claims in the pilot ZCTAs during the event: {len(c)} in {len(with_c)} ZCTAs"]
    if len(with_c):
        lines.append(f"  ZCTAs WITH claims   : mean flooded share {with_c.flooded_share.mean():.1%}, "
                     f"{(with_c.flooded_area_km2 > 0).mean():.0%} have mapped flooding")
    if len(without):
        lines.append(f"  ZCTAs WITHOUT claims: mean flooded share {without.flooded_share.mean():.1%}")
    both = stats.dropna(subset=["nfip_depth_median_in"])
    if len(both):
        lines.append(f"  reported water depth at insured buildings (median of ZCTA medians): "
                     f"{both.nfip_depth_median_in.median() * 0.0254:.2f} m; modeled mean depth in the "
                     f"same ZCTAs: {both.depth_mean_m.median():.2f} m")
    return stats, "\n".join(lines)


def figure(zpoly, stats, rasters, sid):
    import rasterio
    from rasterio.enums import Resampling
    fig, axes = plt.subplots(1, 2, figsize=(15, 7))
    ax = axes[0]
    for h, (dep, _) in rasters.items():
        with rasterio.open(dep) as src:
            f = max(1, int(max(src.width, src.height) / 1500))
            a = src.read(1, out_shape=(src.height // f, src.width // f), resampling=Resampling.average).astype(float)
            a[(a <= 0) | ~np.isfinite(a)] = np.nan
            if src.nodata is not None:
                a[a == src.nodata] = np.nan
            b = src.bounds
            im = ax.imshow(a, extent=(b.left, b.right, b.bottom, b.top), cmap="Blues", vmin=0,
                           vmax=np.nanpercentile(a, 98) if np.isfinite(a).any() else 1)
    zp = zpoly.to_crs(EQUAL_AREA)
    zp.boundary.plot(ax=ax, color="#444444", lw=0.4)
    if rasters:
        fig.colorbar(im, ax=ax, shrink=0.6, label="depth (m)")
    ax.set_title(f"A. Modeled flood depth, {sid} (HAND-FIM, peak NWM flows)")
    ax.set_axis_off()
    ax = axes[1]
    s = stats.sort_values("flooded_share", ascending=True).tail(25)
    ax.barh(s.zcta, 100 * s.flooded_share, color="#3182bd")
    if "nfip_claims" in s:
        for i, (v, n) in enumerate(zip(100 * s.flooded_share, s.nfip_claims)):
            if n:
                ax.text(v, i, f"  {n} claims", va="center", fontsize=7, color="#d62728")
    ax.set(xlabel="% of ZCTA area flooded", title="B. Flooded share per ZCTA (red = NFIP claims)")
    fig.tight_layout()
    fig.savefig(FIG / "fig18_depth_pilot.png", dpi=150)
    plt.close(fig)


# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-dir", default=str(PROJECT_DIR))
    ap.add_argument("--storm", default=None, help="storm_id to map (default: late-February flood)")
    ap.add_argument("--skip-hand", action="store_true", help="rasters already exist; only compute statistics")
    ap.add_argument("--no-population", action="store_true", help="skip the Census block download")
    ap.add_argument("--huc-file", default=None,
                    help="HUC8 polygons (gpkg/shp with a HUC8 column) instead of the online lookup")
    args = ap.parse_args()
    set_paths(Path(args.project_dir))

    sid, win, g, zev = pilot_event(args.storm)
    zb = gpd.read_file(D / "zcta" / "zcta_boundaries_LA.gpkg")
    zb["zcta"] = zb.zcta.astype(str)
    zpoly = zb[zb.main_parish_fips.isin(PILOT_COUNTIES)].copy()
    if args.huc_file:
        hucs = gpd.read_file(args.huc_file)
        hucs["HUC8"] = hucs.HUC8.astype(str)
        hucs = hucs.head(MAX_HUCS)
    else:
        hucs = pilot_hucs(zpoly.to_crs(4326))
    if hucs.empty:
        raise RuntimeError("No HUC8 found for the pilot area")

    files = peak_flows(win, sid, hucs)
    if not args.skip_hand:
        run_hand(hucs, files)
    rasters = raster_paths(hucs, sid)
    if not rasters:
        raise RuntimeError("No depth rasters produced - see the FIMserv messages above")

    blocks = None if args.no_population else load_blocks(zpoly)
    stats = zcta_stats(zpoly, rasters, blocks, hucs)
    stats["in_event"] = stats.zcta.isin(set(zev.zcta))
    stats, ntxt = nfip_check(stats, win)
    stats.to_csv(OUT / f"zcta_depth_pilot_{sid}.csv", index=False)
    figure(zpoly, stats, rasters, sid)

    fl = stats[stats.flooded_area_km2 > 0]
    lines = [f"FLOOD DEPTH PILOT - {sid} ({win[0]:%d %b} - {win[1]:%d %b %Y})",
             "=" * 60,
             f"HUC8 mapped: {', '.join(rasters)}",
             f"ZCTAs analysed (>= {MIN_COVERAGE:.0%} inside the mapped HUC8s): {len(stats)}; "
             f"with mapped flooding: {len(fl)}",
             f"  flooded share of ZCTA area: median {fl.flooded_share.median():.1%}, "
             f"max {stats.flooded_share.max():.1%}" if len(fl) else "  no flooding mapped",
             f"  depth: median of ZCTA max {fl.depth_max_m.median():.2f} m, "
             f"largest {stats.depth_max_m.max():.2f} m" if len(fl) else "",
             f"  ZCTAs in the event (streamflow/any hazard) with mapped flooding: "
             f"{int((stats.in_event & (stats.flooded_area_km2 > 0)).sum())} of {int(stats.in_event.sum())}"]
    if "pop_share_flooded" in stats:
        lines.append(f"  people in flooded cells: {int((stats.population * stats.pop_share_flooded).sum()):,} "
                     f"of {int(stats.population.sum()):,}")
    lines += ["", ntxt,
              "", "Sanity checks: depths of a few metres near the Red River and near zero away from",
              "streams are plausible; tens of metres or whole ZCTAs flooded are not."]
    txt = "\n".join(l for l in lines if l is not None)
    (OUT / "depth_pilot_summary.txt").write_text(txt, encoding="utf-8")
    print("\n" + txt)
    print(f"\nOutputs in {OUT}")


if __name__ == "__main__":
    main()
