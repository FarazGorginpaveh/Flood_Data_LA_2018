# Data dictionary - Louisiana 2018 flood / hazard exposure dataset

Spatial units: **ZCTA = 2020 U.S. Census ZCTA boundaries**; **county = Louisiana parish** (county FIPS). Time: local calendar days and local hours (America/Chicago); hours come from hourly sources, so minutes are always :00.
**Blank cell = missing / not applicable** (reason in the "Missingness" column). No numeric missing codes are used.
Magnitude source flag: observed (USGS) / modeled (NWM) / imputed (parish) / none (hazard without stream flooding).

## Files

| Table | File | Rows | Key |
|---|---|---|---|
| MASTER | `data\deliverable\MASTER_event_zcta_LA_2018.csv` | one row per event x ZCTA - everything requested, columns in the order of the requirements | event_id + zcta |
| ZCTA_events | `data\deliverable\csv\ZCTA_events_LA_2018.csv` | one row per event x ZCTA - all columns (superset of MASTER, original names) | storm_id + zcta |
| County_events | `data\deliverable\csv\County_events_LA_2018.csv` | one row per event x county (parish) | storm_id + county_fips |
| Storms | `data\deliverable\csv\Storms_LA_2018.csv` | one row per event/storm | storm_id |
| ZCTA_daily | `data\deliverable\csv\ZCTA_daily_LA_2018.csv` | every ZCTA x every day of 2018 | zcta + date |
| County_daily | `data\deliverable\csv\County_daily_LA_2018.csv` | every county x every day of 2018 | county_fips + date |
| ZCTA_universe | `data\deliverable\csv\ZCTA_universe_LA_2018.csv` | every Louisiana ZCTA and what can be measured there | zcta |
| County_universe | `data\deliverable\csv\County_universe_LA_2018.csv` | every Louisiana county | county_fips |

All tables are also sheets of `data\deliverable\LA_2018_flood_hazard_dataset.xlsx` (with README and Dictionary sheets).

## MASTER

File: `data\deliverable\MASTER_event_zcta_LA_2018.csv` - one row per event x ZCTA - everything requested, columns in the order of the requirements. Key: **event_id + zcta**.

| Variable | Description | Unit | Type / format | Missingness |
|---|---|---|---|---|
| `event_id` | Unique storm/event ID; one weather system = one ID across all ZCTAs and counties | - | nan | never missing |
| `zcta` | ZIP Code Tabulation Area | - | nan | never missing |
| `zcta_boundary_year` | Census year of the ZCTA boundaries | year | nan | never missing |
| `county_fips` | County (Louisiana parish) FIPS holding most of the ZCTA's land | - | nan | never missing |
| `county_name` | County (parish) name | - | nan | never missing |
| `state` | State | - | nan | never missing |
| `event_type` | tropical cyclone / heavy rainfall - flash flooding / heavy rainfall - river flooding / heavy rainfall - not reported / heavy rainfall - no stream flooding / coastal flooding / flooding - imputed from parish | - | nan | never missing |
| `event_type_basis` | Evidence used for event_type | - | nan | never missing |
| `zcta_event_type` | Type from THIS ZCTA's own hazards (event_type is for the whole event): tropical cyclone / stream flooding / stream flooding (imputed from county) / heavy rain / coastal flooding | - | nan | never missing |
| `hazards` | Hazards in this ZCTA during the event: streamflow, flood_imputed, heavy_rain, coastal, tc | - | nan | never missing |
| `hazard_stream_flooding` | Stream flooding from the ZCTA's own reaches | 0/1 | nan | never missing |
| `hazard_stream_flooding_imputed` | Stream flooding imputed from the county | 0/1 | nan | never missing |
| `hazard_heavy_rain` | Rain with a return period >= 2 years | 0/1 | nan | never missing |
| `hazard_coastal_flooding` | Tide gauge at or above the NOAA minor flood level | 0/1 | nan | never missing |
| `hazard_tropical_cyclone` | Tropical cyclone within 100 km | 0/1 | nan | never missing |
| `event_start_date` | First day of the event anywhere (any ZCTA) | date | nan | never missing |
| `event_end_date` | Last day of the event anywhere | date | nan | never missing |
| `zcta_start_date` | First day of the hazard in this ZCTA | date | nan | never missing |
| `zcta_end_date` | Last day of the hazard in this ZCTA | date | nan | never missing |
| `zcta_peak_date` | Day of the largest flood peak in this ZCTA (first hazard day if no stream flooding) | date | nan | blank = unknown |
| `event_start_time` | Earliest zcta_start_time of the event (local, to the hour) | local time | YYYY-MM-DD HH:MM | never missing |
| `event_end_time` | Latest zcta_end_time of the event (local, to the hour) | local time | YYYY-MM-DD HH:MM | never missing |
| `event_main_day` | Main day of the event: the day with the most ZCTA peaks | local time | nan | never missing |
| `event_peak_span_days` | Days from the first to the last ZCTA peak in the event (long events with a short peak span = slow recession) | local time | nan | never missing |
| `zcta_start_time` | Hour the first stream reach of the ZCTA (or of its county, if imputed) crossed its 2-year flow; day start for rows without stream flooding | local time | YYYY-MM-DD HH:MM | never missing |
| `zcta_peak_time` | Hour of the largest flood peak between the start and end dates - the peak that gives flood_magnitude (stream rows); cyclone closest approach or heaviest rain hour otherwise | local time | YYYY-MM-DD HH:MM | blank = no rain or cyclone in a hazard-only row |
| `zcta_end_time` | Hour the last reach fell back below its 2-year flow; day end for rows without stream flooding | local time | YYYY-MM-DD HH:MM | never missing |
| `time_source` | Where the hours come from: ZCTA stream reaches / county stream reaches (imputed) / day bounds | local time | nan | never missing |
| `flood_magnitude` | Flood magnitude: peak flow / 2-year flow (1 = flood threshold; capped at 10) | ratio | nan | blank = no stream flooding in this ZCTA |
| `flood_magnitude_capped` | 1 = flood_magnitude reached the cap of 10 (true peak ratio is 10 or more) | local time | nan | never missing |
| `flood_magnitude_source` | Flag: observed (USGS) / modeled (NWM) / imputed (parish) / none | - | nan | never missing |
| `flood_return_period_yr` | How rare the flood was (90th percentile of reach peaks, Gumbel fit to 1980-2022) | years | nan | blank = no stream flooding / imputed |
| `flood_return_period_class` | Class of flood_return_period_yr | - | nan | blank = no stream flooding / imputed |
| `flood_depth_max_m` | Maximum flood depth in the flooded area - NOT YET AVAILABLE (needs inundation mapping) | m | nan | always blank (not available) |
| `flood_depth_mean_m` | Mean flood depth in the flooded area - NOT YET AVAILABLE | m | nan | always blank (not available) |
| `flood_depth_popweighted_m` | Population-weighted flood depth - NOT YET AVAILABLE | m | nan | always blank (not available) |
| `observed_depth_insured_buildings_median_in` | Median water depth reported on NFIP insurance claims in this ZCTA during the event (observed, sparse) | inches | nan | blank = no claim |
| `observed_depth_insured_buildings_max_in` | Maximum water depth reported on NFIP claims in this ZCTA during the event | inches | nan | blank = no claim |
| `flood_duration_days` | Duration of the hazard in this ZCTA (zcta_end_date - zcta_start_date + 1) | days | nan | never missing |
| `onset_to_peak_hours` | zcta_peak_time - zcta_start_time: hours from the first threshold crossing in the ZCTA to its largest peak | hours | nan | blank = no stream flooding |
| `rise_time_median_hours` | Paper's rise time: median over the ZCTA's reaches of (each reach's peak - its own threshold crossing) | hours | nan | blank = no stream flooding |
| `severity_index` | flood_magnitude / max(onset_to_peak_hours, 1): a big flood that rises fast scores high; never above flood_magnitude | per hour | nan | blank = no stream flooding |
| `severity_composite` | OPTIONAL composite 0-1: mean percentile rank of return period, extent, duration, 24-h rain | 0-1 | nan | blank = components missing |
| `extent_share_stream_reaches` | Flooding extent proxy: largest share of the ZCTA's stream reaches above the 2-year flow on one day (not area) | fraction 0-1 | nan | blank = no stream flooding |
| `county_share_zctas_affected` | Share of the county's ZCTAs with any hazard in this event | fraction 0-1 | nan | never missing |
| `county_share_land_affected` | Land share of the county's ZCTAs with any hazard in this event (whole ZCTAs) | fraction 0-1 | nan | never missing |
| `precip_event_total_mm` | ZCTA-average rainfall from 1 day before the start to the end (AORC) | mm | nan | blank = rainfall not processed |
| `precip_max_24h_mm` | Largest 24-hour ZCTA-average rainfall inside the same window (<= total) | mm | nan | blank = rainfall not processed |
| `precip_max_24h_return_period_yr` | Return period of precip_max_24h_mm (NOAA Atlas 14) | years | nan | blank = unavailable |
| `precip_max_1h_mm` | Largest 1-hour ZCTA-average rainfall in the same window (1-h <= 24-h <= total) | mm | nan | blank = rainfall not processed |
| `precip_max_1h_cell_mm` | Largest 1-hour rainfall at the wettest ~800 m cell (a point value; can exceed the ZCTA averages) | mm | nan | blank = rainfall not processed |
| `precip_max_1h_cell_return_period_yr` | Return period of precip_max_1h_cell_mm (NOAA Atlas 14 1-h point depth) | years | nan | blank = unavailable |
| `precip_peak_time` | Hour of the heaviest 1-hour ZCTA-average rain in the window | local time | YYYY-MM-DD HH:MM | blank = no rain |
| `coastal_flood_class` | Coastal flooding at the nearest tide gauge: none / minor / moderate / major | - | nan | blank = no tide gauge within 40 km |
| `coastal_water_level_m_above_mhhw` | Highest water level at that gauge during the event | m | nan | blank = no tide gauge within 40 km |
| `event_tropical_cyclone` | Tropical cyclone(s) causing a cyclone hazard (within 100 km) anywhere in the event | - | nan | blank = none |
| `tropical_cyclone_name` | Tropical cyclone passing within 250 km of THIS ZCTA during the event (HURDAT2) | - | nan | blank = none within 250 km |
| `tropical_cyclone_distance_km` | Closest distance of the cyclone centre to the ZCTA | km | nan | blank = none |
| `tropical_cyclone_wind_kt` | Cyclone maximum sustained wind at closest approach (storm intensity) | knots | nan | blank = none |
| `tropical_cyclone_closest_time` | Hour of the linked cyclone's closest approach (HURDAT2, interpolated hourly) | local time | YYYY-MM-DD HH:MM | blank = no cyclone |
| `n_other_zctas_flooded_same_days` | Number of OTHER ZCTAs flooded in the same event on overlapping days | count | nan | never missing |
| `other_zctas_flooded_same_days` | OTHER ZCTAs flooded (stream flooding, own or imputed) in the same event with flood dates overlapping this ZCTA's dates | text ';' | nan | blank = none |
| `n_other_zctas_flooded_in_event` | Number of OTHER ZCTAs flooded anywhere in the same event | count | nan | never missing |
| `other_zctas_flooded_in_event` | OTHER ZCTAs flooded (stream flooding, own or imputed) anywhere in the same event | text ';' | nan | blank = none |
| `other_counties_flooded_same_days` | Counties of the other ZCTAs flooded on overlapping days | text ';' | nan | blank = none |
| `other_counties_flooded_in_event` | Counties of the other ZCTAs flooded in the same event | text ';' | nan | blank = none |
| `n_zctas_in_event` | Number of ZCTAs with ANY hazard in the event (flooding, heavy rain, coastal, cyclone) | count | nan | never missing |
| `other_zctas_in_event` | All other ZCTAs with ANY hazard in the event (this ZCTA excluded) | text ';' | nan | blank = none |
| `n_counties_in_event` | Number of counties in the event | count | nan | never missing |
| `counties_in_event` | FIPS of all counties in the event | text ';' | nan | never missing |
| `county_names_in_event` | Names of all counties in the event | text ';' | nan | never missing |
| `confidence` | Reliability of the stream-flood values: high / medium / low / low (imputed); 'not applicable' when the row has no stream flooding | - | nan | never missing |
| `n_stream_reaches` | Usable NWM stream reaches in the ZCTA | count | nan | never missing |
| `nfip_claims` | FEMA flood insurance claims in the ZCTA during the event | count | nan | blank = claims not processed |
| `nfip_paid_usd` | Paid on those claims | USD | nan | blank = claims not processed |

## ZCTA_events

File: `data\deliverable\csv\ZCTA_events_LA_2018.csv` - one row per event x ZCTA - all columns (superset of MASTER, original names). Key: **storm_id + zcta**.

| Variable | Description | Unit | Type / format | Missingness |
|---|---|---|---|---|
| `storm_id` | Storm/event ID; one weather system = one ID across ZCTAs | - | text | never missing |
| `zcta` | ZIP Code Tabulation Area (2020 Census boundaries), 5 characters | - | text | never missing |
| `county_fips` | County (Louisiana parish) FIPS code, 5 characters | - | text | never missing |
| `county_name` | County (parish) name | - | text | never missing |
| `storm_origin` | streamflow storm (from step 10) or hazard-only storm (no stream flooding in the storm) | - | category | never missing |
| `event_type` | tropical cyclone / heavy rainfall - flash flooding / heavy rainfall - river flooding / heavy rainfall - not reported | - | category | never missing |
| `event_type_basis` | Evidence for event_type (HURDAT2 track, Storm Events cause or type, streamflow only) | - | category | never missing |
| `hazards` | Hazards that occurred in the ZCTA during this storm window: streamflow, flood_imputed, heavy_rain, coastal, tc | - | text; ';'-separated | never missing |
| `hazard_streamflow` | Stream flooding from the ZCTA's own reaches | - | 0/1 | never missing |
| `hazard_flood_imputed` | Stream flooding imputed from the main parish (ZCTA without usable reaches) | - | 0/1 | never missing |
| `hazard_heavy_rain` | At least one heavy-rain day (return period >= 2 yr) | - | 0/1 | never missing |
| `hazard_coastal` | At least one day at or above the minor coastal flood level at the nearest tide gauge | - | 0/1 | never missing (0 also where no gauge; see has_tide_gauge) |
| `hazard_tc` | Tropical cyclone closest approach within 100 km (+/- 1 day) | - | 0/1 | never missing |
| `start_date` | First local day of streamflow flooding in the ZCTA during this storm | date | YYYY-MM-DD | never missing |
| `end_date` | Last local day of streamflow flooding in the ZCTA during this storm | date | YYYY-MM-DD | never missing |
| `peak_date` | Local day of the largest flood peak in the ZCTA | date | YYYY-MM-DD | blank = not available |
| `length_days` | Flooding duration: end_date - start_date + 1 | days | integer | never missing |
| `magnitude_best` | Flood magnitude: largest peak flow / 2-year flow (1 = threshold; capped at 10); observed if available, else modeled | ratio | number | blank = not available (no reach peak in the window) |
| `magnitude_source` | Source of magnitude_best: observed (USGS) / modeled (NWM) / none; 'imputed' reserved, not used | - | category | never missing |
| `return_period_p90` | Robust return period: 90th percentile of the return periods of the reach peaks (Gumbel fit to 1980-2022 NWM annual maxima) | years | number (1-100) | blank = not available |
| `return_period_class` | Class of return_period_p90 | - | category | blank = not available |
| `max_frac_reaches` | Extent proxy: largest share of the ZCTA's stream reaches above the 2-year flow on one day (NOT area) | fraction 0-1 | number | never missing |
| `onset_to_peak_h` | Time from flood onset (threshold crossing) to peak, median over the ZCTA's reach events | hours | number | blank = not available |
| `severity_max_norm` | Severity: peak ratio / onset-to-peak time (largest reach value) | per hour | number | blank = not available |
| `severity_composite` | OPTIONAL suggested composite: mean percentile rank (0-1) of return_period_p90, max_frac_reaches, length_days, rain_max_24h_mm | 0-1 | number | blank = not available |
| `rain_event_total_mm` | ZCTA areal-mean rainfall from start_date - 1 day to end_date (AORC v1.1) | mm | number | blank = rainfall not processed |
| `rain_max_24h_mm` | Largest 24-hour areal-mean rainfall in that window | mm | number | blank = rainfall not processed |
| `rain_rp_24h` | Return period of rain_max_24h_mm vs NOAA Atlas 14 24-h point depths (conservative for large ZCTAs) | years | number (1-1000) | blank = Atlas 14 unavailable |
| `rain_max_1h_cell_mm` | Largest 1-hour rainfall at any ~800 m cell in the ZCTA in that window | mm | number | blank = rainfall not processed |
| `rain_rp_1h_cell` | Return period of rain_max_1h_cell_mm vs NOAA Atlas 14 1-h point depths | years | number (1-1000) | blank = Atlas 14 unavailable |
| `coastal_flood_class` | Coastal flooding at that gauge: none / minor / moderate / major (NOAA NOS CO-OPS 086 thresholds) | - | category | blank = no tide gauge within 40 km |
| `coastal_wl_max_m_mhhw` | Highest daily-max water level at the nearest tide gauge (within 40 km) in the window, above MHHW | m | number | blank = no tide gauge within 40 km |
| `coastal_report` | NWS Coastal Flood / Storm Surge reports in the ZCTA's main parish during the window | - | text | blank = none |
| `tc_name` | Tropical cyclone whose closest approach fell within the storm window (HURDAT2) | - | text | blank = no tropical cyclone within 500 km |
| `tc_dist_km` | Closest distance of the cyclone centre to the ZCTA centroid | km | number | blank = none |
| `tc_wind_kt` | Cyclone maximum sustained wind at closest approach (storm intensity, not local wind) | knots | number | blank = none |
| `tc_category` | Saffir-Simpson category at closest approach | - | category | blank = none |
| `tc_rain_mm` | ZCTA rainfall from 2 days before to 1 day after closest approach | mm | number | blank = none or rainfall not processed |
| `confidence` | Reliability of the flood measures: high / medium / low (parish evaluation; urban ZCTAs one level lower) | - | category | never missing |
| `n_reaches` | Usable NWM stream reaches in the ZCTA (reliability indicator) | count | integer | never missing |
| `n_flood_events_combined` | Number of ZCTA flood events combined into this storm-ZCTA row | count | integer | never missing |
| `magnitude_modeled` | NWM peak / 2-year flow (capped at 10) | ratio | number | blank = not available |
| `magnitude_observed` | USGS gauge peak / 2-year flow (capped at 10), if a usable gauge in the ZCTA flooded | ratio | number | blank = no usable gauge flooded |
| `return_period_max` | Largest single-reach return period (capped at 100; often hits the cap) | years | number (1-100) | blank = not available |
| `max_reaches_flooding` | Largest number of the ZCTA's reaches above the 2-year flow on one day | count | integer | never missing |
| `observed_stage_above_flood_ft` | USGS stage above NWS flood stage, if a stage gauge in the ZCTA flooded | feet | number | blank = no such gauge |
| `usgs_gauges` | USGS gauges in the ZCTA that flooded during the storm | - | text; ';'-separated | blank = none |
| `rain_max_1h_mm` | Largest 1-hour areal-mean rainfall in that window | mm | number | blank = rainfall not processed |
| `tc_nhc_id` | NHC storm ID of that cyclone | - | text | blank = none |
| `storm_start_date` | First flood day of the whole storm (any ZCTA) | date | YYYY-MM-DD | never missing |
| `storm_end_date` | Last flood day of the whole storm | date | YYYY-MM-DD | never missing |
| `storm_peak_day` | Main day of the storm: day with the most ZCTA peaks | date | YYYY-MM-DD | never missing |
| `storm_n_zctas` | Number of ZCTAs flooded in the storm | count | integer | never missing |
| `storm_zctas` | All ZCTAs flooded in the storm | - | text; ';'-separated | never missing |
| `storm_n_counties` | Number of counties with any hazard in the storm | count | integer | never missing |
| `storm_counties` | All counties with any hazard in the storm | - | text; ';'-separated | never missing |
| `storm_county_names` | Names of those counties | - | text; ';'-separated | never missing |
| `other_zctas_in_storm` | All other ZCTAs with any hazard in the same storm (this ZCTA excluded) | - | text; ';'-separated | blank = none |
| `n_other_zctas_in_storm` | Number of other ZCTAs in the same storm | count | integer | never missing |
| `other_zctas_flooded_in_event` | OTHER ZCTAs flooded (stream flooding, own or imputed) anywhere in the same event | - | text; ';'-separated | blank = none |
| `n_other_zctas_flooded_in_event` | Number of those ZCTAs | count | integer | never missing |
| `other_zctas_flooded_same_days` | OTHER ZCTAs flooded in the same event on days overlapping this ZCTA's dates | - | text; ';'-separated | blank = none |
| `n_other_zctas_flooded_same_days` | Number of those ZCTAs | count | integer | never missing |
| `other_counties_flooded_in_event` | Counties of the other flooded ZCTAs in the event | - | text; ';'-separated | blank = none |
| `n_other_counties_flooded_in_event` | Number of those counties | count | integer | never missing |
| `other_counties_flooded_same_days` | Counties of the other ZCTAs flooded on overlapping days | - | text; ';'-separated | blank = none |
| `nfip_claims` | FEMA NFIP flood insurance claims with a date of loss in the window (start - 1 day to end + 1 day) | count | integer | blank = claims not processed (step 11) |
| `nfip_paid_usd` | Building + contents paid on those claims | USD | number | blank = claims not processed |

## County_events

File: `data\deliverable\csv\County_events_LA_2018.csv` - one row per event x county (parish). Key: **storm_id + county_fips**.

| Variable | Description | Unit | Type / format | Missingness |
|---|---|---|---|---|
| `storm_id` | Storm/event ID; one weather system = one ID across ZCTAs | - | text | never missing |
| `county_fips` | County (Louisiana parish) FIPS code, 5 characters | - | text | never missing |
| `county_name` | County (parish) name | - | text | never missing |
| `storm_origin` | streamflow storm (from step 10) or hazard-only storm (no stream flooding in the storm) | - | category | never missing |
| `event_type` | tropical cyclone / heavy rainfall - flash flooding / heavy rainfall - river flooding / heavy rainfall - not reported | - | category | never missing |
| `event_type_basis` | Evidence for event_type (HURDAT2 track, Storm Events cause or type, streamflow only) | - | category | never missing |
| `hazards` | Hazards that occurred in the ZCTA during this storm window: streamflow, flood_imputed, heavy_rain, coastal, tc | - | text; ';'-separated | never missing |
| `hazard_streamflow` | Stream flooding from the ZCTA's own reaches | - | 0/1 | never missing |
| `hazard_flood_imputed` | Stream flooding imputed from the main parish (ZCTA without usable reaches) | - | 0/1 | never missing |
| `hazard_heavy_rain` | At least one heavy-rain day (return period >= 2 yr) | - | 0/1 | never missing |
| `hazard_coastal` | At least one day at or above the minor coastal flood level at the nearest tide gauge | - | 0/1 | never missing (0 also where no gauge; see has_tide_gauge) |
| `hazard_tc` | Tropical cyclone closest approach within 100 km (+/- 1 day) | - | 0/1 | never missing |
| `start_date` | First local day of streamflow flooding in the ZCTA during this storm | date | YYYY-MM-DD | never missing |
| `end_date` | Last local day of streamflow flooding in the ZCTA during this storm | date | YYYY-MM-DD | never missing |
| `length_days` | Flooding duration: end_date - start_date + 1 | days | integer | never missing |
| `n_zctas_affected` | ZCTAs of this county with any hazard in the storm | count | integer | never missing |
| `zctas_affected` | Those ZCTAs | - | text; ';'-separated | never missing |
| `n_zctas_in_county` | All Louisiana ZCTAs whose main county is this county | count | integer | never missing |
| `share_zctas_affected` | n_zctas_affected / n_zctas_in_county (county extent measure) | fraction 0-1 | number | never missing |
| `share_area_affected_zcta` | Land area of affected ZCTAs / land area of all the county's ZCTAs (extent measure; whole ZCTAs, not flooded area) | fraction 0-1 | number | never missing |
| `magnitude_max_zcta` | Largest ZCTA magnitude_best in the county (peak / 2-yr flow) | ratio | number | blank = no stream flooding |
| `magnitude_source_of_max` | Source of magnitude_max_zcta | - | category | never missing |
| `return_period_p90_max` | Largest ZCTA robust return period in the county | years | number | blank = no stream flooding |
| `max_frac_reaches_max` | Largest ZCTA extent proxy in the county | fraction 0-1 | number | blank = no stream flooding |
| `onset_to_peak_h_median` | Median ZCTA onset-to-peak time | hours | number | blank = no stream flooding |
| `severity_max_norm` | Severity: peak ratio / onset-to-peak time (largest reach value) | per hour | number | blank = not available |
| `severity_composite_max` | Largest ZCTA severity_composite in the county | 0-1 | number | blank = components missing |
| `rain_event_total_mm_areal` | Area-weighted mean event rainfall over the affected ZCTAs | mm | number | blank = rainfall not processed |
| `rain_max_24h_mm_max` | Largest 24-h ZCTA rainfall in the window | mm | number | blank = rainfall not processed |
| `rain_rp_24h_max` | Largest 24-h rainfall return period (Atlas 14) | years | number | blank = unavailable |
| `rain_max_1h_cell_mm_max` | Largest 1-h rainfall at any cell | mm | number | blank = rainfall not processed |
| `rain_rp_1h_cell_max` | Largest 1-h rainfall return period (Atlas 14) | years | number | blank = unavailable |
| `coastal_flood_class_worst` | Worst coastal flood class among the ZCTAs (none/minor/moderate/major) | - | category | blank = no tide gauge |
| `coastal_wl_max_m_mhhw` | Highest daily-max water level at the nearest tide gauge (within 40 km) in the window, above MHHW | m | number | blank = no tide gauge within 40 km |
| `coastal_report` | NWS Coastal Flood / Storm Surge reports in the ZCTA's main parish during the window | - | text | blank = none |
| `tc_name` | Tropical cyclone whose closest approach fell within the storm window (HURDAT2) | - | text | blank = no tropical cyclone within 500 km |
| `tc_dist_km_min` | Closest tropical-cyclone distance to any affected ZCTA | km | number | blank = no cyclone |
| `tc_wind_kt` | Cyclone maximum sustained wind at closest approach (storm intensity, not local wind) | knots | number | blank = none |
| `zcta_confidence_values` | Confidence levels of the county's affected ZCTA rows | - | text; ';'-separated | never missing |
| `county_flood_days` | Parish-level streamflow flood days in the window (step 7 dataset) | days | integer | blank = no reliable parish data |
| `county_flood_magnitude` | Parish-level largest peak / 2-yr flow in the window | ratio | number | blank = no parish flood day |
| `county_onset_to_peak_h` | Parish-level median rise time in the window | hours | number | blank = no parish flood day |
| `county_severity_norm` | Parish-level largest severity in the window | per hour | number | blank = no parish flood day |
| `county_frac_reaches_max` | Largest share of the parish's reaches above the 2-yr flow in the window | fraction 0-1 | number | blank = no data |
| `county_big_river_flood_days` | Days with Mississippi / Atchafalaya / lower Red River flooding in the parish | days | integer | never missing |
| `county_flood_source` | Parish streamflow source: NWM / USGS / none | - | category | never missing |
| `county_confidence` | Parish confidence (step 6) | - | category | never missing |
| `nfip_claims` | FEMA NFIP flood insurance claims with a date of loss in the window (start - 1 day to end + 1 day) | count | integer | blank = claims not processed (step 11) |
| `nfip_paid_usd` | Building + contents paid on those claims | USD | number | blank = claims not processed |
| `storm_start_date` | First flood day of the whole storm (any ZCTA) | date | YYYY-MM-DD | never missing |
| `storm_end_date` | Last flood day of the whole storm | date | YYYY-MM-DD | never missing |
| `storm_n_zctas` | Number of ZCTAs flooded in the storm | count | integer | never missing |
| `storm_zctas` | All ZCTAs flooded in the storm | - | text; ';'-separated | never missing |
| `storm_n_counties` | Number of counties with any hazard in the storm | count | integer | never missing |
| `storm_counties` | All counties with any hazard in the storm | - | text; ';'-separated | never missing |
| `storm_county_names` | Names of those counties | - | text; ';'-separated | never missing |
| `other_counties_in_storm` | All other counties in the same storm (this county excluded) | - | text; ';'-separated | blank = none |
| `n_other_counties_in_storm` | Number of other counties in the same storm | count | integer | never missing |

## Storms

File: `data\deliverable\csv\Storms_LA_2018.csv` - one row per event/storm. Key: **storm_id**.

| Variable | Description | Unit | Type / format | Missingness |
|---|---|---|---|---|
| `storm_id` | Storm/event ID; one weather system = one ID across ZCTAs | - | text | never missing |
| `storm_origin` | streamflow storm (from step 10) or hazard-only storm (no stream flooding in the storm) | - | category | never missing |
| `event_type` | tropical cyclone / heavy rainfall - flash flooding / heavy rainfall - river flooding / heavy rainfall - not reported | - | category | never missing |
| `event_type_basis` | Evidence for event_type (HURDAT2 track, Storm Events cause or type, streamflow only) | - | category | never missing |
| `start_date` | First local day of streamflow flooding in the ZCTA during this storm | date | YYYY-MM-DD | never missing |
| `end_date` | Last local day of streamflow flooding in the ZCTA during this storm | date | YYYY-MM-DD | never missing |
| `peak_day` | Main day of the storm (day with the most ZCTA peaks; first day for hazard-only storms) | date | YYYY-MM-DD | never missing |
| `length_days` | Flooding duration: end_date - start_date + 1 | days | integer | never missing |
| `n_zctas_streamflow` | ZCTAs in the storm with own stream flooding | count | integer | never missing |
| `n_zctas_flood_imputed` | ZCTAs in the storm with flooding imputed from the parish | count | integer | never missing |
| `n_zctas_heavy_rain` | ZCTAs with heavy rain (storm) / on that day (county daily) | count | integer | blank = rainfall not processed |
| `n_zctas_coastal` | ZCTAs in the storm with coastal flooding | count | integer | never missing |
| `n_zctas_tc` | ZCTAs in the storm with a tropical cyclone within 100 km | count | integer | never missing |
| `n_zctas` | Number of ZCTAs in the storm / county | count | integer | never missing |
| `zctas` | All ZCTAs in the storm | - | text; ';'-separated | never missing |
| `n_counties` | Number of counties in the storm | count | integer | never missing |
| `counties` | All counties in the storm | - | text; ';'-separated | never missing |
| `county_names` | Names of the counties in the storm | - | text; ';'-separated | never missing |
| `tc_name` | Tropical cyclone whose closest approach fell within the storm window (HURDAT2) | - | text | blank = no tropical cyclone within 500 km |
| `magnitude_max` | Largest magnitude in the storm | ratio | number | blank = no stream flooding |
| `return_period_p90_max` | Largest ZCTA robust return period in the county | years | number | blank = no stream flooding |
| `rain_max_24h_mm_max` | Largest 24-h ZCTA rainfall in the window | mm | number | blank = rainfall not processed |
| `rain_rp_24h_max` | Largest 24-h rainfall return period (Atlas 14) | years | number | blank = unavailable |
| `coastal_flood_class_worst` | Worst coastal flood class among the ZCTAs (none/minor/moderate/major) | - | category | blank = no tide gauge |
| `onset_to_peak_h_median` | Median ZCTA onset-to-peak time | hours | number | blank = no stream flooding |
| `severity_max_norm` | Severity: peak ratio / onset-to-peak time (largest reach value) | per hour | number | blank = not available |
| `share_rows_observed` | Share of the storm's ZCTA rows with an observed (USGS) magnitude | fraction | number | never missing |
| `share_rows_imputed` | Share of the storm's ZCTA rows with an imputed (parish) magnitude | fraction | number | never missing |
| `nws_episode_ids` | NWS Storm Events episode IDs linked to the storm | - | text; ';'-separated | blank = no NWS report |
| `nws_flood_cause` | Flood cause written in the linked NWS reports | - | text | blank = no NWS report |
| `n_areas_merged` | Separate flooded areas joined into this streamflow storm (step 10) | count | integer | blank = hazard-only storm |
| `peak_span_days` | Days from the first to the last ZCTA peak (streamflow storms, max 10) | days | integer | blank = hazard-only storm |
| `nfip_claims` | FEMA NFIP flood insurance claims with a date of loss in the window (start - 1 day to end + 1 day) | count | integer | blank = claims not processed (step 11) |
| `nfip_paid_usd` | Building + contents paid on those claims | USD | number | blank = claims not processed |

## ZCTA_daily

File: `data\deliverable\csv\ZCTA_daily_LA_2018.csv` - every ZCTA x every day of 2018. Key: **zcta + date**.

| Variable | Description | Unit | Type / format | Missingness |
|---|---|---|---|---|
| `zcta` | ZIP Code Tabulation Area (2020 Census boundaries), 5 characters | - | text | never missing |
| `date` | Local calendar day (America/Chicago) | date | YYYY-MM-DD | never missing |
| `flood_day` | Streamflow flood day in the ZCTA (>= 2 reaches and >= 2% of reaches above the 2-year flow) | - | 0/1 | blank = no data (see data_status) |
| `flood_magnitude` | Largest peak / 2-yr flow among events peaking that day | ratio | number | blank = no flood / no data |
| `reaches_flooding` | Reaches above the 2-year flow that day | count | integer | blank = no data |
| `frac_flooding` | Share of the ZCTA's reaches above the 2-year flow that day | fraction 0-1 | number | blank = no data |
| `data_status` | included / no data: unverified parish / no data: fewer than 5 reaches | - | category | never missing |
| `streamflow_status` | ZCTA reaches / imputed from parish / missing (unverified parish) | - | category | never missing |
| `flood_day_filled` | flood_day, or the main parish's flood day for ZCTAs without usable reaches | - | 0/1 | blank = no data (unverified parish) |
| `flood_source` | Streamflow source (NWM / USGS / none, or ZCTA reaches / imputed) | - | category | never missing |
| `flood_magnitude_filled` | flood_magnitude, or the parish magnitude when imputed | ratio | number | 0 on non-flood days; blank = no data |
| `rain_total_mm` | Areal-mean daily rainfall | mm | number | blank = rainfall not processed |
| `rain_max_1h_cell_mm_day` | Largest 1-hour rainfall at any cell that day | mm | number | blank = rainfall not processed |
| `heavy_rain_day` | Daily rainfall or wettest cell-hour with a return period >= 2 years (possible pluvial / urban flooding) | - | 0/1 | blank = rainfall not processed |
| `coastal_flood_class_day` | Tide-gauge coastal flood class that day | - | category | blank = no tide gauge within 40 km |
| `coastal_hazard_day` | Tide-gauge water level at or above the minor flood level that day | - | 0/1 | blank = no tide gauge within 40 km |
| `tc_within_250km` | A tropical cyclone's closest approach within 250 km happened that day | - | 0/1 | never missing |
| `tc_event_day` | Tropical cyclone within 100 km, from 1 day before to 1 day after closest approach | - | 0/1 | never missing |
| `any_hazard_day` | Any of: flood_day_filled, heavy_rain_day, coastal_hazard_day, tc_event_day | - | 0/1 | never missing |
| `in_storm_id` | storm_id if the day falls inside a storm-ZCTA window of the main table | - | text | blank = not in a storm |
| `county_fips` | County (Louisiana parish) FIPS code, 5 characters | - | text | never missing |

## County_daily

File: `data\deliverable\csv\County_daily_LA_2018.csv` - every county x every day of 2018. Key: **county_fips + date**.

| Variable | Description | Unit | Type / format | Missingness |
|---|---|---|---|---|
| `county_fips` | County (Louisiana parish) FIPS code, 5 characters | - | text | never missing |
| `county_name` | County (parish) name | - | text | never missing |
| `date` | Local calendar day (America/Chicago) | date | YYYY-MM-DD | never missing |
| `confidence` | Reliability of the flood measures: high / medium / low (parish evaluation; urban ZCTAs one level lower) | - | category | never missing |
| `flood_source` | Streamflow source (NWM / USGS / none, or ZCTA reaches / imputed) | - | category | never missing |
| `flood_day` | Streamflow flood day in the ZCTA (>= 2 reaches and >= 2% of reaches above the 2-year flow) | - | 0/1 | blank = no data (see data_status) |
| `flood_magnitude` | Largest peak / 2-yr flow among events peaking that day | ratio | number | blank = no flood / no data |
| `onset_to_peak_h` | Time from flood onset (threshold crossing) to peak, median over the ZCTA's reach events | hours | number | blank = not available |
| `severity_norm` | Parish severity that day: peak ratio / rise time | per hour | number | blank = no flood / no data |
| `frac_reaches_flooding` | Share of the county's reaches above the 2-yr flow that day | fraction 0-1 | number | blank = no data |
| `big_river_flood_day` | Mississippi / Atchafalaya / lower Red River flooding in the county that day | - | True/False | never missing |
| `usgs_gauges_flooding` | USGS gauges in the county above their threshold that day | count | integer | never missing |
| `n_zctas_heavy_rain` | ZCTAs with heavy rain (storm) / on that day (county daily) | count | integer | blank = rainfall not processed |
| `n_zctas_coastal_flood` | ZCTAs of the county at or above minor coastal flooding that day | count | integer | blank = no tide gauge |
| `n_zctas_tc_within_100km` | ZCTAs of the county with a cyclone within 100 km that day | count | integer | never missing |
| `n_zctas_any_hazard` | ZCTAs of the county with any hazard that day | count | integer | never missing |
| `rain_total_mm_areal` | Area-weighted mean daily rainfall over the county's ZCTAs | mm | number | blank = rainfall not processed |
| `rain_max_1h_cell_mm` | Largest 1-hour rainfall at any ~800 m cell in the ZCTA in that window | mm | number | blank = rainfall not processed |

## ZCTA_universe

File: `data\deliverable\csv\ZCTA_universe_LA_2018.csv` - every Louisiana ZCTA and what can be measured there. Key: **zcta**.

| Variable | Description | Unit | Type / format | Missingness |
|---|---|---|---|---|
| `zcta` | ZIP Code Tabulation Area (2020 Census boundaries), 5 characters | - | text | never missing |
| `county_fips` | County (Louisiana parish) FIPS code, 5 characters | - | text | never missing |
| `county_name` | County (parish) name | - | text | never missing |
| `n_reaches` | Usable NWM stream reaches in the ZCTA (reliability indicator) | count | integer | never missing |
| `urban` | More than half of the ZCTA's land is Census urban area | - | 0/1 | blank = not available |
| `confidence` | Reliability of the flood measures: high / medium / low (parish evaluation; urban ZCTAs one level lower) | - | category | never missing |
| `data_status` | included / no data: unverified parish / no data: fewer than 5 reaches | - | category | never missing |
| `streamflow_status` | ZCTA reaches / imputed from parish / missing (unverified parish) | - | category | never missing |
| `has_tide_gauge` | A tide gauge within 40 km provides coastal flooding | - | 0/1 | never missing |
| `n_hazard_rows` | Rows of this ZCTA in the all-hazard main table | count | integer | never missing |
| `n_storm_zcta_rows` | Rows of this ZCTA in the main table | count | integer | never missing |

## County_universe

File: `data\deliverable\csv\County_universe_LA_2018.csv` - every Louisiana county. Key: **county_fips**.

| Variable | Description | Unit | Type / format | Missingness |
|---|---|---|---|---|
| `county_fips` | County (Louisiana parish) FIPS code, 5 characters | - | text | never missing |
| `county_name` | County (parish) name | - | text | never missing |
| `confidence` | Reliability of the flood measures: high / medium / low (parish evaluation; urban ZCTAs one level lower) | - | category | never missing |
| `flood_source` | Streamflow source (NWM / USGS / none, or ZCTA reaches / imputed) | - | category | never missing |
| `streamflow_flood_events_parish` | Parish flood events in the year (step 7) | count | integer | blank = no reliable data |
| `streamflow_flood_days_parish` | Parish flood days in the year (step 7) | days | integer | blank = no reliable data |
| `big_river_flood_days` | Days with big-river flooding in the county in 2018 | days | integer | never missing |
| `n_zctas` | Number of ZCTAs in the storm / county | count | integer | never missing |
| `n_zctas_with_reaches` | ZCTAs of the county with their own usable stream reaches | count | integer | never missing |
| `n_storm_county_rows` | Rows of this county in County_events | count | integer | never missing |
